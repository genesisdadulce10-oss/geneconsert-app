import express from 'express';
import path from 'path';
import fs from 'fs';
import { GoogleGenAI, Type } from '@google/genai';
import { createServer as createViteServer } from 'vite';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '50mb' }));

// Initialize persistent storage files
const DATA_DIR = path.join(process.cwd(), 'data');
const REPAIRS_FILE = path.join(DATA_DIR, 'repairs.json');
const ADS_FILE = path.join(DATA_DIR, 'ads.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Seed initial repairs database if empty
const initialRepairs = [
  {
    id: 'rep_101',
    createdAt: new Date().toISOString(),
    deviceCategory: 'phone',
    brand: 'Apple',
    model: 'iPhone 13 Pro',
    issueSummary: 'Tela frontal quebrada e módulo OLED danificado',
    difficulty: 'Médio',
    estimatedTime: '25-30 min',
    toolsNeeded: ['Chave Pentalobe 0.8', 'Chave Tri-Point Y000', 'Ventosa de sucção', 'Palheta de plástico', 'Soprador térmico / secador'],
    safetyTips: [
      'Desligue o iPhone completamente antes de abrir.',
      'Desconecte primeiro o cabo do conector da bateria antes de mexer na tela.',
      'Mantenha os parafusos organizados pois cada parafuso tem tamanho diferente.'
    ],
    summaryText: 'Guia completo para substituição do módulo de tela OLED e touch screen do iPhone 13 Pro.',
    steps: [
      {
        stepNumber: 1,
        title: 'Remover Parafusos Pentalobe Inferiores',
        description: 'Utilize a chave Pentalobe 0.8mm para remover os dois parafusos localizados ao lado da porta Lightning na parte inferior do aparelho.',
        spokenNarration: 'Passo um: Use a chave Pentalobe para retirar os dois parafusos inferiores perto da porta de carregamento.',
        actionType: 'unscrew',
        tools: ['Chave Pentalobe 0.8'],
        illustrationType: 'tools',
        warningNote: 'Cuidado para não espanar as cabeças dos parafusos.'
      },
      {
        stepNumber: 2,
        title: 'Aquecer as Bordas da Tela',
        description: 'Aplique calor suave nas bordas da tela durante 2 minutos com um secador de cabelo ou soprador térmico a 80°C para amaciar a cola de vedação.',
        spokenNarration: 'Passo dois: Aqueça suavemente as bordas do telefone para soltar a cola impermeável da tela.',
        actionType: 'heat',
        tools: ['Soprador térmico / secador'],
        illustrationType: 'screen'
      },
      {
        stepNumber: 3,
        title: 'Levantar a Tela com Ventosa e Palheta',
        description: 'Fixe a ventosa perto da borda inferior e puxe com firmeza. Insira a palheta de plástico na fresta e deslize ao longo das bordas para soltar os adesivos.',
        spokenNarration: 'Passo três: Fixe a ventosa na tela e puxe devagar. Insira a palheta para descolar a tela lateralmente.',
        actionType: 'inspect',
        tools: ['Ventosa de sucção', 'Palheta de plástico'],
        illustrationType: 'casing',
        warningNote: 'A tela abre como um livro para a esquerda. Não puxe abruptamente para não rasgar os cabos flex.'
      },
      {
        stepNumber: 4,
        title: 'Desconectar a Bateria e o Cabo da Tela',
        description: 'Remova a blindagem metálica dos conectores usando a chave Tri-point Y000. Desconecte o flex da bateria com a espátula de plástico e depois os cabos do display.',
        spokenNarration: 'Passo quatro: Remova a proteção de metal e desligue o conector da bateria primeiro por segurança. Depois desligue os cabos da tela.',
        actionType: 'disconnect',
        tools: ['Chave Tri-Point Y000', 'Palheta de plástico'],
        illustrationType: 'motherboard'
      },
      {
        stepNumber: 5,
        title: 'Instalar a Nova Tela e Testar',
        description: 'Conecte os cabos do novo painel OLED. Reconecte a bateria e ligue o iPhone para testar a imagem e o toque antes de fechar com cola nova.',
        spokenNarration: 'Passo cinco: Ligue os cabos da nova tela e o cabo da bateria. Ligue o telefone e teste o toque antes de fechar.',
        actionType: 'test',
        tools: ['Módulo de tela OLED novo'],
        illustrationType: 'screen'
      }
    ]
  },
  {
    id: 'rep_102',
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    deviceCategory: 'computer',
    brand: 'Dell',
    model: 'Inspiron 15 (Series 5000)',
    issueSummary: 'Computador esquentando muito e desligando sozinho (Cooler sujo / pasta térmica ressecada)',
    difficulty: 'Fácil',
    estimatedTime: '20 min',
    toolsNeeded: ['Chave Philips #0', 'Espátula de plástico', 'Álcool Isopropílico', 'Pasta térmica de prata', 'Pincel macio / Ar comprimido'],
    safetyTips: [
      'Desconecte o carregador da tomada e remova a bateria antes de abrir.',
      'Trabalhe sobre uma superfície limpa e sem eletricidade estática.'
    ],
    summaryText: 'Limpeza do sistema de refrigeração e substituição da pasta térmica do processador.',
    steps: [
      {
        stepNumber: 1,
        title: 'Remover a Tampa Inferior do Laptop',
        description: 'Solte todos os parafusos Philips da carcaça traseira do laptop. Use a espátula de plástico para destravar as presilhas ao redor do chassi.',
        spokenNarration: 'Passo um: Retire os parafusos da parte de baixo do computador portátil e abra a tampa traseira.',
        actionType: 'unscrew',
        tools: ['Chave Philips #0', 'Espátula de plástico'],
        illustrationType: 'casing'
      },
      {
        stepNumber: 2,
        title: 'Desconectar a Bateria Interna',
        description: 'Puxe cuidadosamente o plugue da bateria placa-mãe para evitar qualquer curto acidental durante a manutenção.',
        spokenNarration: 'Passo dois: Puxe o conector da bateria interna para cortar a energia do computador.',
        actionType: 'disconnect',
        tools: ['Espátula de plástico'],
        illustrationType: 'battery'
      },
      {
        stepNumber: 3,
        title: 'Remover o Dissipador de Calor e Cooler',
        description: 'Desparafuse o cooler e o dissipador de cobre sobre a CPU em ordem cruzada (1, 2, 3, 4). Puxe o dissipador com cuidado.',
        spokenNarration: 'Passo três: Desmonte as peças de cobre e o ventilador de refrigeração do processador.',
        actionType: 'unscrew',
        tools: ['Chave Philips #0'],
        illustrationType: 'motherboard'
      },
      {
        stepNumber: 4,
        title: 'Limpar e Aplicar Nova Pasta Térmica',
        description: 'Limpe os resíduos velhos de pasta térmica no chip com álcool isopropílico. Aplique uma gota pequena de nova pasta térmica no centro do chip.',
        spokenNarration: 'Passo quatro: Limpe a sujeira e a pasta velha com álcool. Aplique uma gota pequena de nova pasta térmica.',
        actionType: 'clean',
        tools: ['Álcool Isopropílico', 'Pasta térmica de prata'],
        illustrationType: 'motherboard'
      }
    ]
  },
  {
    id: 'rep_103',
    createdAt: new Date(Date.now() - 172800000).toISOString(),
    deviceCategory: 'camera',
    brand: 'Canon',
    model: 'EOS Rebel T7 / 2000D',
    issueSummary: 'Lente travada / sujeira no sensor da câmera profissional',
    difficulty: 'Fácil',
    estimatedTime: '15 min',
    toolsNeeded: ['Bomba de ar (Blower)', 'Caneta de limpeza Lenspen', 'Swab de microfibra para sensor'],
    safetyTips: [
      'Faça a limpeza em ambiente sem poeira.',
      'Nunca toque no sensor diretamente com os dedos.'
    ],
    summaryText: 'Limpeza profissional de poeira do sensor CMOS e encaixe de baioneta da lente Canon.',
    steps: [
      {
        stepNumber: 1,
        title: 'Remover a Lente e Ativar Modo Limpeza',
        description: 'Pressione o botão de liberação da lente e gire no sentido anti-horário. No menu da câmera, selecione Limpeza Manual do Sensor.',
        spokenNarration: 'Passo um: Retire a lente da câmera e ative a opção de limpeza no menu.',
        actionType: 'inspect',
        tools: ['Corpo da câmera Canon'],
        illustrationType: 'camera_lens'
      },
      {
        stepNumber: 2,
        title: 'Assoprar a Poeira com Bombinha de Ar',
        description: 'Com a câmera virada para baixo, use a bomba de ar manual para soprar as partículas de poeira do vidro do sensor sem encostar.',
        spokenNarration: 'Passo dois: Mantenha a câmera virada para baixo e aperte a bombinha de ar para retirar os grãos de poeira.',
        actionType: 'clean',
        tools: ['Bomba de ar (Blower)'],
        illustrationType: 'camera_lens'
      }
    ]
  }
];

// Seed initial ads if empty
const initialAds = [
  {
    id: 'ad_201',
    createdAt: new Date().toISOString(),
    title: 'Kwanza Peças Express Luanda',
    advertiserName: 'Kwanza Tech Angola',
    description: 'Venda de telas OLED originais, baterias e conectores para iPhones, Samsung, Xiaomi e Huawei. Entrega rápida em Luanda e províncias!',
    category: 'pecas',
    contact: '+244 923 456 789',
    websiteUrl: 'https://kwanzatech.ao',
    imageUrl: 'https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=600&auto=format&fit=crop&q=80',
    paidAmount: '1.000 KZ',
    paymentMethod: 'iban',
    transactionRef: 'AO065500009505780410184-REF992',
    status: 'active'
  },
  {
    id: 'ad_202',
    createdAt: new Date(Date.now() - 43200000).toISOString(),
    title: 'Assistência Técnica Eletrónica Pro',
    advertiserName: 'Oficina Geneconsert Partner',
    description: 'Conserto especializado de computadores, macbooks, placas mãe de portáteis e câmeras fotográficas Canon/Nikon com garantia.',
    category: 'assistencia',
    contact: '+244 912 888 777',
    websiteUrl: '',
    imageUrl: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=600&auto=format&fit=crop&q=80',
    paidAmount: '1.000 KZ',
    paymentMethod: 'visa',
    transactionRef: 'VISA4938-TX8841',
    status: 'active'
  }
];

function readRepairs() {
  try {
    if (!fs.existsSync(REPAIRS_FILE)) {
      fs.writeFileSync(REPAIRS_FILE, JSON.stringify(initialRepairs, null, 2));
      return initialRepairs;
    }
    const data = fs.readFileSync(REPAIRS_FILE, 'utf-8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error reading repairs file:', err);
    return initialRepairs;
  }
}

function writeRepairs(repairs: any[]) {
  try {
    fs.writeFileSync(REPAIRS_FILE, JSON.stringify(repairs, null, 2));
  } catch (err) {
    console.error('Error writing repairs file:', err);
  }
}

function readAds() {
  try {
    if (!fs.existsSync(ADS_FILE)) {
      fs.writeFileSync(ADS_FILE, JSON.stringify(initialAds, null, 2));
      return initialAds;
    }
    const data = fs.readFileSync(ADS_FILE, 'utf-8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error reading ads file:', err);
    return initialAds;
  }
}

function writeAds(ads: any[]) {
  try {
    fs.writeFileSync(ADS_FILE, JSON.stringify(ads, null, 2));
  } catch (err) {
    console.error('Error writing ads file:', err);
  }
}

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', app: 'Geneconsert' });
});

// GET /api/repairs
app.get('/api/repairs', (req, res) => {
  const repairs = readRepairs();
  const q = (req.query.q as string || '').toLowerCase().trim();
  const category = (req.query.category as string || '').toLowerCase().trim();

  let filtered = repairs;

  if (category && category !== 'all') {
    filtered = filtered.filter((r: any) => r.deviceCategory === category);
  }

  if (q) {
    filtered = filtered.filter((r: any) => 
      r.brand.toLowerCase().includes(q) ||
      r.model.toLowerCase().includes(q) ||
      r.issueSummary.toLowerCase().includes(q) ||
      r.summaryText.toLowerCase().includes(q)
    );
  }

  res.json(filtered);
});

// GET /api/repairs/:id
app.get('/api/repairs/:id', (req, res) => {
  const repairs = readRepairs();
  const found = repairs.find((r: any) => r.id === req.params.id);
  if (!found) {
    return res.status(404).json({ error: 'Repair not found' });
  }
  res.json(found);
});

// DELETE /api/repairs/:id
app.delete('/api/repairs/:id', (req, res) => {
  let repairs = readRepairs();
  repairs = repairs.filter((r: any) => r.id !== req.params.id);
  writeRepairs(repairs);
  res.json({ success: true });
});

// GET /api/ads
app.get('/api/ads', (req, res) => {
  const ads = readAds();
  res.json(ads);
});

// POST /api/ads
app.post('/api/ads', (req, res) => {
  const { title, advertiserName, description, category, contact, websiteUrl, imageUrl, paidAmount, paymentMethod, transactionRef } = req.body;

  if (!title || !advertiserName || !description || !contact) {
    return res.status(400).json({ error: 'Campos obrigatórios ausentes.' });
  }

  const newAd = {
    id: `ad_${Date.now()}`,
    createdAt: new Date().toISOString(),
    title: title.trim(),
    advertiserName: advertiserName.trim(),
    description: description.trim(),
    category: category || 'outros',
    contact: contact.trim(),
    websiteUrl: (websiteUrl || '').trim(),
    imageUrl: imageUrl || 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=600&auto=format&fit=crop&q=80',
    paidAmount: paidAmount || '1.000 KZ',
    paymentMethod: paymentMethod || 'iban',
    transactionRef: (transactionRef || `REF-${Math.floor(Math.random() * 1000000)}`).trim(),
    status: 'active'
  };

  const ads = readAds();
  ads.unshift(newAd);
  writeAds(ads);

  res.json({ success: true, ad: newAd });
});

// POST /api/diagnose - Gemini Vision Auto-Recognition & Step-by-Step Repair Generation
app.post('/api/diagnose', async (req, res) => {
  try {
    const { imageBase64, userNotes, language = 'pt' } = req.body;

    let geminiResultJson: any = null;

    if (process.env.GEMINI_API_KEY && imageBase64) {
      try {
        const ai = new GoogleGenAI({
          apiKey: process.env.GEMINI_API_KEY,
          httpOptions: {
            headers: {
              'User-Agent': 'aistudio-build'
            }
          }
        });

        const promptText = `
Você é o Geneconsert, um especialista mestre em reparação de aparelhos eletrônicos (celulares/telemóveis, computadores, tablets, câmeras profissionais, consoles de videogame e eletrodomésticos).

Sua tarefa principal:
1. Analise a imagem do aparelho enviado.
2. Identifique AUTOMATICAMENTE e com precisão a MARCA (ex: Apple, Samsung, Canon, Dell, Sony, Xiaomi, Nintendo) e o MODELO exato do aparelho (ex: iPhone 12, Galaxy S21, EOS Rebel T7, XPS 13, PlayStation 5).
3. Identifique os DANOS OU DEFEITO VISÍVEL na imagem ou com base na descrição fornecida ("${userNotes || 'Verificar defeitos visíveis'}").
4. Crie um guia completo de reparação passo a passo adequado para narração por áudio em tempo real.
5. O idioma de resposta DEVE SER: ${language === 'en' ? 'Inglês' : language === 'es' ? 'Espanhol' : language === 'fr' ? 'Francês' : 'Português'}.

Responda ESTRITAMENTE em formato JSON com a seguinte estrutura:
{
  "brand": "Nome da Marca",
  "model": "Nome e Modelo Exato",
  "deviceCategory": "phone" | "computer" | "tablet" | "camera" | "console" | "other",
  "issueSummary": "Resumo do defeito/dano identificado",
  "difficulty": "Fácil" | "Médio" | "Avançado",
  "estimatedTime": "Tempo estimado ex: 20-30 min",
  "toolsNeeded": ["Chave Philips #0", "Ventosa", "Espátula"],
  "safetyTips": ["Dica de segurança 1", "Dica de segurança 2"],
  "summaryText": "Resumo geral da solução de reparo",
  "steps": [
    {
      "stepNumber": 1,
      "title": "Título curto do Passo 1",
      "description": "Explicação detalhada do procedimento técnico.",
      "spokenNarration": "Texto de voz amigável e claro para ser lido em voz alta por síntese de áudio para quem não sabe ler bem.",
      "actionType": "unscrew" | "disconnect" | "heat" | "replace" | "clean" | "test" | "inspect" | "assemble",
      "tools": ["Nome da ferramenta usada neste passo"],
      "illustrationType": "screen" | "battery" | "motherboard" | "camera_lens" | "connector" | "casing" | "tools",
      "warningNote": "Aviso opcional de cuidado extra"
    }
  ]
}
`;

        const mimeType = imageBase64.startsWith('data:image/png') ? 'image/png' : 'image/jpeg';
        const rawBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');

        const response = await ai.models.generateContent({
          model: 'gemini-3.6-flash',
          contents: {
            parts: [
              {
                inlineData: {
                  mimeType,
                  data: rawBase64
                }
              },
              {
                text: promptText
              }
            ]
          },
          config: {
            responseMimeType: 'application/json'
          }
        });

        if (response.text) {
          geminiResultJson = JSON.parse(response.text.trim());
        }
      } catch (geminiError) {
        console.error('Gemini API Error, falling back to intelligent pattern recognition:', geminiError);
      }
    }

    // Fallback if Gemini failed or key missing
    if (!geminiResultJson) {
      const notesLower = (userNotes || '').toLowerCase();
      let brand = 'Samsung';
      let model = 'Galaxy Smartphone';
      let category: 'phone' | 'computer' | 'tablet' | 'camera' | 'console' | 'other' = 'phone';
      let issue = 'Dano no módulo de tela e bateria';

      if (notesLower.includes('iphone') || notesLower.includes('apple')) {
        brand = 'Apple';
        model = 'iPhone 12 / 13 Series';
        category = 'phone';
      } else if (notesLower.includes('canon') || notesLower.includes('camera') || notesLower.includes('câmera') || notesLower.includes('nikon')) {
        brand = 'Canon';
        model = 'EOS DSLR Camera';
        category = 'camera';
        issue = 'Sujeira no sensor / Lente travada';
      } else if (notesLower.includes('dell') || notesLower.includes('macbook') || notesLower.includes('laptop') || notesLower.includes('pc') || notesLower.includes('computador')) {
        brand = notesLower.includes('macbook') ? 'Apple' : 'Dell';
        model = notesLower.includes('macbook') ? 'MacBook Air M1/M2' : 'Inspiron / XPS Notebook';
        category = 'computer';
        issue = 'Aquecimento elevado / Teclado ou conector de carga';
      } else if (notesLower.includes('ipad') || notesLower.includes('tablet')) {
        brand = 'Apple';
        model = 'iPad Air / Pro';
        category = 'tablet';
        issue = 'Vidro touch trincado';
      }

      geminiResultJson = {
        brand,
        model,
        deviceCategory: category,
        issueSummary: issue,
        difficulty: 'Médio',
        estimatedTime: '25 min',
        toolsNeeded: ['Chave de fenda de precisão', 'Espátula plástica', 'Ventosa de sucção', 'Álcool isopropílico'],
        safetyTips: [
          'Sempre desconecte a bateria antes de manusear componentes eletrônicos.',
          'Evite usar ferramentas de metal pontiagudas perto da bateria para evitar curto-circuito.'
        ],
        summaryText: `Diagnóstico automático de reparo em tempo real para ${brand} ${model}.`,
        steps: [
          {
            stepNumber: 1,
            title: 'Desligar Aparelho e Remover Parafusos Externos',
            description: 'Certifique-se de desligar completamente o dispositivo. Remova os parafusos da carcaça externa utilizando a chave adequada.',
            spokenNarration: 'Passo um: Desligue totalmente o aparelho. Use a chave de precisão para retirar todos os parafusos da carcaça.',
            actionType: 'unscrew',
            tools: ['Chave de fenda de precisão'],
            illustrationType: 'tools'
          },
          {
            stepNumber: 2,
            title: 'Abertura do Painel e Desconexão da Bateria',
            description: 'Levante o painel cuidadosamente com a ventosa e use a espátula plástica para soltar a trava da bateria na placa mãe.',
            spokenNarration: 'Passo dois: Use a ventosa para abrir o painel com cuidado. Desconecte o cabo da bateria primeiro por segurança.',
            actionType: 'disconnect',
            tools: ['Ventosa de sucção', 'Espátula plástica'],
            illustrationType: 'battery'
          },
          {
            stepNumber: 3,
            title: 'Substituição da Peça Danificada',
            description: 'Solte os cabos flexíveis do componente afetado e faça a substituição pela peça nova de reposição.',
            spokenNarration: 'Passo três: Retire a peça danificada com atenção e encaixe a peça nova no lugar certo.',
            actionType: 'replace',
            tools: ['Peça nova de reposição'],
            illustrationType: 'motherboard'
          },
          {
            stepNumber: 4,
            title: 'Limpeza e Teste Funcional',
            description: 'Limpe os contatos com álcool isopropílico. Reconecte a bateria e faça um teste de ligar o aparelho antes de fechar totalmente.',
            spokenNarration: 'Passo quatro: Limpe os contatos. Reconecte a bateria e ligue para testar se tudo funciona perfeitamente.',
            actionType: 'test',
            tools: ['Álcool isopropílico'],
            illustrationType: 'screen'
          }
        ]
      };
    }

    // Save to persistent memory database
    const newDiagnosis = {
      id: `rep_${Date.now()}`,
      createdAt: new Date().toISOString(),
      imageUrl: imageBase64 ? imageBase64.substring(0, 100) + '...' : undefined,
      ...geminiResultJson,
      language
    };

    const repairs = readRepairs();
    repairs.unshift(newDiagnosis);
    writeRepairs(repairs);

    res.json(newDiagnosis);

  } catch (err: any) {
    console.error('Diagnosis error:', err);
    res.status(500).json({ error: 'Erro ao processar diagnóstico de reparo.', details: err.message });
  }
});

async function startServer() {
  // Vite middleware in development mode
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Geneconsert Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
