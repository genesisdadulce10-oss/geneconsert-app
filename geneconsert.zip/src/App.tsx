import React, { useState } from 'react';
import { ThemeMode, Language, RepairDiagnosis } from './types';
import { Header } from './components/Header';
import { ScannerView } from './components/ScannerView';
import { RepairGuideView } from './components/RepairGuideView';
import { HistoryView } from './components/HistoryView';
import { AdPlatformView } from './components/AdPlatformView';
import { AccessibilityFooter } from './components/AccessibilityFooter';

export default function App() {
  const [theme, setTheme] = useState<ThemeMode>('black');
  const [language, setLanguage] = useState<Language>('pt');
  const [activeTab, setActiveTab] = useState<'scan' | 'history' | 'ads'>('scan');
  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [currentDiagnosis, setCurrentDiagnosis] = useState<RepairDiagnosis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [audioActive, setAudioActive] = useState<boolean>(false);

  // Background Theme Styles mapping
  const getThemeClasses = (mode: ThemeMode) => {
    switch (mode) {
      case 'white':
        return 'bg-white text-gray-900 font-sans';
      case 'black':
        return 'bg-[#090d16] text-gray-100 font-sans';
      case 'blue':
        return 'bg-[#0f172a] text-blue-50 font-sans';
      case 'green':
        return 'bg-[#062c1b] text-emerald-50 font-sans';
    }
  };

  const getFontSizeClass = (size: 'normal' | 'large' | 'xlarge') => {
    switch (size) {
      case 'normal': return 'text-base';
      case 'large': return 'text-lg';
      case 'xlarge': return 'text-xl';
    }
  };

  const handleDiagnoseComplete = (diagnosis: RepairDiagnosis) => {
    setCurrentDiagnosis(diagnosis);
    setActiveTab('scan');
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${getThemeClasses(theme)} ${getFontSizeClass(fontSize)} selection:bg-emerald-500 selection:text-white flex flex-col justify-between`}>
      
      <div>
        {/* Header bar */}
        <Header
          theme={theme}
          setTheme={setTheme}
          language={language}
          setLanguage={setLanguage}
          activeTab={activeTab}
          setActiveTab={(tab) => {
            setActiveTab(tab);
            if (tab !== 'scan') {
              // Keep diagnosis context if coming back
            }
          }}
          fontSize={fontSize}
          setFontSize={setFontSize}
          audioActive={audioActive}
        />

        {/* Main Content Area */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          
          {activeTab === 'scan' ? (
            currentDiagnosis ? (
              <RepairGuideView
                diagnosis={currentDiagnosis}
                language={language}
                onBack={() => setCurrentDiagnosis(null)}
                setAudioActive={setAudioActive}
              />
            ) : (
              <ScannerView
                language={language}
                onDiagnoseComplete={handleDiagnoseComplete}
                isAnalyzing={isAnalyzing}
                setIsAnalyzing={setIsAnalyzing}
              />
            )
          ) : activeTab === 'history' ? (
            <HistoryView
              language={language}
              onSelectDiagnosis={(diagnosis) => {
                setCurrentDiagnosis(diagnosis);
                setActiveTab('scan');
              }}
            />
          ) : (
            <AdPlatformView language={language} />
          )}

        </main>
      </div>

      {/* Accessibility Footer */}
      <AccessibilityFooter language={language} />

    </div>
  );
}
