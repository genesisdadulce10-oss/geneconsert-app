export type ThemeMode = 'white' | 'black' | 'blue' | 'green';

export type Language = 'pt' | 'en' | 'es' | 'fr';

export type DeviceCategory = 'phone' | 'computer' | 'tablet' | 'camera' | 'console' | 'other';

export interface RepairStep {
  stepNumber: number;
  title: string;
  description: string;
  spokenNarration: string;
  actionType: 'unscrew' | 'disconnect' | 'heat' | 'replace' | 'clean' | 'test' | 'inspect' | 'assemble';
  tools: string[];
  warningNote?: string;
  illustrationType: 'screen' | 'battery' | 'motherboard' | 'camera_lens' | 'connector' | 'casing' | 'tools';
}

export interface RepairDiagnosis {
  id: string;
  createdAt: string;
  deviceCategory: DeviceCategory;
  brand: string;
  model: string;
  issueSummary: string;
  difficulty: 'Fácil' | 'Médio' | 'Avançado' | 'Easy' | 'Medium' | 'Advanced';
  estimatedTime: string;
  toolsNeeded: string[];
  safetyTips: string[];
  steps: RepairStep[];
  imageUrl?: string;
  summaryText: string;
  language?: Language;
}

export interface Advertisement {
  id: string;
  createdAt: string;
  title: string;
  advertiserName: string;
  description: string;
  category: 'pecas' | 'assistencia' | 'ferramentas' | 'outros';
  contact: string; // WhatsApp or Phone
  websiteUrl?: string;
  imageUrl?: string;
  paidAmount: string; // e.g. "1.000 KZ" or "$1.10 USD"
  paymentMethod: 'iban' | 'visa';
  transactionRef: string;
  status: 'active' | 'pending';
}
