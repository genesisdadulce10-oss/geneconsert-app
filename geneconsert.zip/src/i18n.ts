import { Language } from './types';

export interface Translations {
  appName: string;
  tagline: string;
  themeWhite: string;
  themeBlack: string;
  themeBlue: string;
  themeGreen: string;
  tabFixNow: string;
  tabHistory: string;
  tabAds: string;
  pressEnterToStart: string;
  enterButtonText: string;
  enterSubtitle: string;
  uploadPhoto: string;
  takePhoto: string;
  dragDropImage: string;
  selectFile: string;
  analyzingDevice: string;
  autoDetectingBrand: string;
  commonIssuesTitle: string;
  screenCracked: string;
  batteryNotCharging: string;
  cameraBlurry: string;
  noPower: string;
  overheating: string;
  waterDamage: string;
  repairGuideTitle: string;
  brandModelLabel: string;
  detectedProblem: string;
  difficultyLabel: string;
  timeEstimateLabel: string;
  toolsNeededTitle: string;
  safetyTitle: string;
  audioPlayerTitle: string;
  stepOf: string;
  playAudio: string;
  pauseAudio: string;
  nextStep: string;
  prevStep: string;
  speedLabel: string;
  simplifiedMode: string;
  simplifiedModeActive: string;
  historyTitle: string;
  searchHistoryPlaceholder: string;
  filterAll: string;
  filterPhones: string;
  filterComputers: string;
  filterTablets: string;
  filterCameras: string;
  filterConsoles: string;
  noHistoryFound: string;
  adSectionTitle: string;
  adSectionSubtitle: string;
  publishAdButton: string;
  adPriceNotice: string;
  ibanPaymentTitle: string;
  visaPaymentTitle: string;
  adFormTitle: string;
  businessName: string;
  adTitle: string;
  adDescription: string;
  contactWhatsApp: string;
  websiteOptional: string;
  paymentMethodSelect: string;
  txRefLabel: string;
  submitAdButton: string;
  adSuccessMsg: string;
  freeAppBadge: string;
  accessibilityNotice: string;
  audioNarrationActive: string;
  clearHistory: string;
  reopenGuide: string;
}

export const translations: Record<Language, Translations> = {
  pt: {
    appName: 'Geneconsert',
    tagline: 'Assistente Inteligente para Reparação de Eletrônicos em Tempo Real',
    themeWhite: 'Branca',
    themeBlack: 'Preto',
    themeBlue: 'Azul',
    themeGreen: 'Verde',
    tabFixNow: 'Consertar Agora',
    tabHistory: 'Memória & Histórico',
    tabAds: 'Anúncios & Propaganda',
    pressEnterToStart: 'Pressione ENTER ou clique no botão abaixo para iniciar a narração e reprodução em tempo real',
    enterButtonText: 'ENTER / REPRODUZIR ÁUDIO E VÍDEO',
    enterSubtitle: 'Inicia o diagnóstico e narração por voz passo a passo',
    uploadPhoto: 'Carregar Foto do Aparelho',
    takePhoto: 'Tirar Foto com a Câmera',
    dragDropImage: 'Arraste uma foto aqui ou tire uma fotografia do seu aparelho',
    selectFile: 'Selecionar Imagem',
    analyzingDevice: 'Identificando marca, modelo e danos com Inteligência Artificial...',
    autoDetectingBrand: 'Identificação Automática de Marca & Modelo',
    commonIssuesTitle: 'Principais problemas detectados:',
    screenCracked: 'Tela / Touch Quebrado',
    batteryNotCharging: 'Bateria não carrega',
    cameraBlurry: 'Câmera embaçada ou sem imagem',
    noPower: 'Aparelho não liga',
    overheating: 'Sobreaquecimento / Cooler barulhento',
    waterDamage: 'Caiu na água / Umidade',
    repairGuideTitle: 'Guia de Conserto em Tempo Real',
    brandModelLabel: 'Aparelho Reconhecido:',
    detectedProblem: 'Diagnóstico:',
    difficultyLabel: 'Dificuldade:',
    timeEstimateLabel: 'Tempo Estimado:',
    toolsNeededTitle: 'Ferramentas Necessárias',
    safetyTitle: 'Instruções de Segurança',
    audioPlayerTitle: 'Reprodutor de Áudio & Narração Passo a Passo',
    stepOf: 'Passo {current} de {total}',
    playAudio: 'Ouvir Instrução',
    pauseAudio: 'Pausar Áudio',
    nextStep: 'Próximo Passo',
    prevStep: 'Passo Anterior',
    speedLabel: 'Velocidade do Áudio:',
    simplifiedMode: 'Modo Simplificado (Acessibilidade / Baixa Alfabetização)',
    simplifiedModeActive: 'Ícones grandes e narração falada ativados',
    historyTitle: 'Banco de Dados & Memória de Consertos Anteriores',
    searchHistoryPlaceholder: 'Pesquisar por marca, modelo ou defeito (ex: iPhone, Samsung, Canon)...',
    filterAll: 'Todos',
    filterPhones: 'Telemóveis / Telefones',
    filterComputers: 'Computadores / Laptops',
    filterTablets: 'Tablets',
    filterCameras: 'Câmeras Profissionais',
    filterConsoles: 'Consolas / Jogos',
    noHistoryFound: 'Nenhum histórico encontrado com estes termos.',
    adSectionTitle: 'Espaço de Anúncios & Propaganda',
    adSectionSubtitle: 'Divulgue o seu negócio, oficina de reparação ou venda de peças para milhares de utilizadores.',
    publishAdButton: 'Anunciar o Seu Negócio (1.000 Kz)',
    adPriceNotice: 'Taxa fixa: 1.000 KZ (ou equivalente em qualquer moeda internacional USD, EUR, BRL, ZAR)',
    ibanPaymentTitle: 'Pagamento via IBAN Angola:',
    visaPaymentTitle: 'Pagamento via Cartão Visa Internacional:',
    adFormTitle: 'Formulário de Cadastro de Anúncio',
    businessName: 'Nome da Sua Empresa / Negócio',
    adTitle: 'Título do Anúncio',
    adDescription: 'Descrição dos seus produtos ou serviços',
    contactWhatsApp: 'Contacto (WhatsApp ou Telefone com código de país)',
    websiteOptional: 'Website ou Rede Social (opcional)',
    paymentMethodSelect: 'Forma de Pagamento Utilizada',
    txRefLabel: 'Nº do Comprovativo / Referência de Transação',
    submitAdButton: 'Enviar Anúncio para Publicação',
    adSuccessMsg: 'Anúncio registado com sucesso! Estará visível imediatamente no aplicativo.',
    freeAppBadge: '100% Gratuito para todos os utilizadores',
    accessibilityNotice: 'Projetado para fácil uso por pessoas de qualquer idade e com necessidades de acessibilidade.',
    audioNarrationActive: 'Narração de voz ativa. Pressione a tecla ENTER para pausar/retomar.',
    clearHistory: 'Limpar Histórico',
    reopenGuide: 'Abrir Guia de Conserto',
  },
  en: {
    appName: 'Geneconsert',
    tagline: 'Smart Real-Time Electronics Repair & Accessibility Assistant',
    themeWhite: 'White',
    themeBlack: 'Black',
    themeBlue: 'Blue',
    themeGreen: 'Green',
    tabFixNow: 'Fix Now',
    tabHistory: 'Memory & History',
    tabAds: 'Advertisements',
    pressEnterToStart: 'Press ENTER or click the button below to start real-time audio narration & steps',
    enterButtonText: 'ENTER / PLAY AUDIO & VIDEO',
    enterSubtitle: 'Starts automatic diagnosis & step-by-step voice guidance',
    uploadPhoto: 'Upload Device Photo',
    takePhoto: 'Take Photo with Camera',
    dragDropImage: 'Drag & drop a device picture or snap a photo of your electronic device',
    selectFile: 'Select Image File',
    analyzingDevice: 'Identifying brand, model, and visual faults using AI...',
    autoDetectingBrand: 'Automatic Brand & Model Recognition',
    commonIssuesTitle: 'Common issues identified:',
    screenCracked: 'Broken Screen / Touch Fault',
    batteryNotCharging: 'Battery won\'t charge',
    cameraBlurry: 'Blurry camera / No video output',
    noPower: 'Device won\'t turn on',
    overheating: 'Overheating / Fan noise',
    waterDamage: 'Water damage / Moisture',
    repairGuideTitle: 'Real-Time Repair Guide',
    brandModelLabel: 'Recognized Device:',
    detectedProblem: 'Diagnostic:',
    difficultyLabel: 'Difficulty:',
    timeEstimateLabel: 'Estimated Time:',
    toolsNeededTitle: 'Required Tools',
    safetyTitle: 'Safety Precautions',
    audioPlayerTitle: 'Audio Player & Step-by-Step Voice Narration',
    stepOf: 'Step {current} of {total}',
    playAudio: 'Listen to Step',
    pauseAudio: 'Pause Audio',
    nextStep: 'Next Step',
    prevStep: 'Previous Step',
    speedLabel: 'Voice Speed:',
    simplifiedMode: 'Simplified Visual Mode (Accessibility & Low-Literacy)',
    simplifiedModeActive: 'Large icons and spoken instructions enabled',
    historyTitle: 'Database & Search Memory of Past Repairs',
    searchHistoryPlaceholder: 'Search by brand, model, or defect (e.g. iPhone, Dell, Canon)...',
    filterAll: 'All',
    filterPhones: 'Phones',
    filterComputers: 'Computers & Laptops',
    filterTablets: 'Tablets',
    filterCameras: 'Cameras',
    filterConsoles: 'Gaming Consoles',
    noHistoryFound: 'No past repair history matches your query.',
    adSectionTitle: 'Sponsor & Business Advertisements',
    adSectionSubtitle: 'Promote your repair shop, parts store, or services to users worldwide.',
    publishAdButton: 'Post Your Business Ad (1,000 KZ)',
    adPriceNotice: 'Fixed price: 1,000 KZ (or equivalent in USD $1.10, EUR €1.00, BRL R$6.00, etc.)',
    ibanPaymentTitle: 'Payment via Angola IBAN:',
    visaPaymentTitle: 'Payment via International Visa Card:',
    adFormTitle: 'Advertisement Submission Form',
    businessName: 'Your Business / Shop Name',
    adTitle: 'Ad Title',
    adDescription: 'Product or service description',
    contactWhatsApp: 'Contact (Phone / WhatsApp with country code)',
    websiteOptional: 'Website or Social Link (optional)',
    paymentMethodSelect: 'Payment Method Used',
    txRefLabel: 'Transaction Reference / Receipt ID',
    submitAdButton: 'Submit Ad for Instant Publication',
    adSuccessMsg: 'Advertisement successfully created! It is now live in the app.',
    freeAppBadge: '100% Free for all users',
    accessibilityNotice: 'Designed for effortless accessibility for all ages and literacy levels.',
    audioNarrationActive: 'Voice narration active. Press ENTER key to pause/resume.',
    clearHistory: 'Clear History',
    reopenGuide: 'Open Repair Guide',
  },
  es: {
    appName: 'Geneconsert',
    tagline: 'Asistente Inteligente de Reparación de Electrónica en Tiempo Real',
    themeWhite: 'Blanco',
    themeBlack: 'Negro',
    themeBlue: 'Azul',
    themeGreen: 'Verde',
    tabFixNow: 'Reparar Ahora',
    tabHistory: 'Memoria e Historial',
    tabAds: 'Anuncios y Publicidad',
    pressEnterToStart: 'Presione ENTER o toque el botón abajo para iniciar la narración de audio en tiempo real',
    enterButtonText: 'ENTER / REPRODUCIR AUDIO Y VÍDEO',
    enterSubtitle: 'Inicia el diagnóstico y la guía por voz paso a paso',
    uploadPhoto: 'Cargar Foto del Dispositivo',
    takePhoto: 'Tomar Foto con la Cámara',
    dragDropImage: 'Arrastre una foto o tome una foto de su aparato electrónico',
    selectFile: 'Seleccionar Imagen',
    analyzingDevice: 'Identificando marca, modelo y fallas con Inteligencia Artificial...',
    autoDetectingBrand: 'Reconocimiento Automático de Marca y Modelo',
    commonIssuesTitle: 'Problemas principales detectados:',
    screenCracked: 'Pantalla rota / Touch dañado',
    batteryNotCharging: 'La batería no carga',
    cameraBlurry: 'Cámara borrosa o sin imagen',
    noPower: 'El equipo no enciende',
    overheating: 'Sobrecalentamiento / Ruido de ventilador',
    waterDamage: 'Daño por agua o humedad',
    repairGuideTitle: 'Guía de Reparación en Tiempo Real',
    brandModelLabel: 'Dispositivo Reconocido:',
    detectedProblem: 'Diagnóstico:',
    difficultyLabel: 'Dificultad:',
    timeEstimateLabel: 'Tiempo Estimado:',
    toolsNeededTitle: 'Herramientas Necesarias',
    safetyTitle: 'Instrucciones de Seguridad',
    audioPlayerTitle: 'Reproductor de Audio y Narración Paso a Paso',
    stepOf: 'Paso {current} de {total}',
    playAudio: 'Escuchar Paso',
    pauseAudio: 'Pausar Audio',
    nextStep: 'Siguiente Paso',
    prevStep: 'Paso Anterior',
    speedLabel: 'Velocidad de Voz:',
    simplifiedMode: 'Modo Simplificado (Accesibilidad y Lectura Fácil)',
    simplifiedModeActive: 'Iconos grandes e instrucciones habladas activadas',
    historyTitle: 'Base de Datos y Memoria de Reparaciones Anteriores',
    searchHistoryPlaceholder: 'Buscar por marca, modelo o falla (ej: iPhone, Samsung, Canon)...',
    filterAll: 'Todos',
    filterPhones: 'Teléfonos',
    filterComputers: 'Computadoras',
    filterTablets: 'Tabletas',
    filterCameras: 'Cámaras',
    filterConsoles: 'Consolas de Juego',
    noHistoryFound: 'No hay historial para esta búsqueda.',
    adSectionTitle: 'Espacio de Anuncios y Publicidad',
    adSectionSubtitle: 'Anuncie su taller de reparación o tienda de repuestos a nivel internacional.',
    publishAdButton: 'Publicar Anuncio (1.000 Kz)',
    adPriceNotice: 'Tarifa fija: 1.000 KZ (o equivalente en moneda internacional USD, EUR, BRL)',
    ibanPaymentTitle: 'Pago por IBAN Angola:',
    visaPaymentTitle: 'Pago por Tarjeta Visa Internacional:',
    adFormTitle: 'Formulario de Publicación de Anuncio',
    businessName: 'Nombre de su Empresa / Negocio',
    adTitle: 'Título del Anuncio',
    adDescription: 'Descripción de sus productos o servicios',
    contactWhatsApp: 'Contacto (Teléfono o WhatsApp con código de país)',
    websiteOptional: 'Sitio Web o Red Social (opcional)',
    paymentMethodSelect: 'Forma de Pago Utilizada',
    txRefLabel: 'Referencia del Pago / Recibo',
    submitAdButton: 'Enviar Anuncio para Publicación',
    adSuccessMsg: '¡Anuncio registrado con éxito! Ya está visible en la aplicación.',
    freeAppBadge: '100% Gratis para todos los usuarios',
    accessibilityNotice: 'Diseñado para uso accesible por personas de cualquier edad y nivel de lectura.',
    audioNarrationActive: 'Narración de voz activa. Presione ENTER para pausar o reanudar.',
    clearHistory: 'Limpiar Historial',
    reopenGuide: 'Abrir Guía',
  },
  fr: {
    appName: 'Geneconsert',
    tagline: 'Assistant Intelligent de Réparation Électronique en Temps Réel',
    themeWhite: 'Blanc',
    themeBlack: 'Noir',
    themeBlue: 'Bleu',
    themeGreen: 'Vert',
    tabFixNow: 'Réparer Maintenant',
    tabHistory: 'Mémoire & Historique',
    tabAds: 'Annonces & Publicité',
    pressEnterToStart: 'Appuyez sur ENTRÉE ou cliquez sur le bouton ci-dessous pour lancer la narration audio',
    enterButtonText: 'ENTRÉE / JOUER AUDIO ET VIDÉO',
    enterSubtitle: 'Démarre le diagnostic et la lecture audio étape par étape',
    uploadPhoto: 'Télécharger une photo de l\'appareil',
    takePhoto: 'Prendre une photo',
    dragDropImage: 'Déposez une photo ou prenez un cliché de votre appareil électronique',
    selectFile: 'Sélectionner l\'image',
    analyzingDevice: 'Identification de la marque, du modèle et des pannes par IA...',
    autoDetectingBrand: 'Reconnaissance Automatique de la Marque & du Modèle',
    commonIssuesTitle: 'Problèmes fréquents détectés :',
    screenCracked: 'Écran cassé / Tactile hors service',
    batteryNotCharging: 'La batterie ne charge pas',
    cameraBlurry: 'Caméra floue / Pas d\'image',
    noPower: 'L\'appareil ne s\'allume pas',
    overheating: 'Surchauffe / Bruit de ventilateur',
    waterDamage: 'Tombé dans l\'eau / Humidité',
    repairGuideTitle: 'Guide de Réparation en Temps Réel',
    brandModelLabel: 'Appareil Reconnu :',
    detectedProblem: 'Diagnostic :',
    difficultyLabel: 'Difficulté :',
    timeEstimateLabel: 'Temps Estimé :',
    toolsNeededTitle: 'Outils Nécessaires',
    safetyTitle: 'Consignes de Sécurité',
    audioPlayerTitle: 'Lecteur Audio et Narration Étape par Étape',
    stepOf: 'Étape {current} sur {total}',
    playAudio: 'Écouter l\'étape',
    pauseAudio: 'Mettre en pause',
    nextStep: 'Étape Suivante',
    prevStep: 'Étape Précédente',
    speedLabel: 'Vitesse de Lecture :',
    simplifiedMode: 'Mode Simplifié (Accessibilité & Lecture Facile)',
    simplifiedModeActive: 'Grands icônes et instructions vocales activés',
    historyTitle: 'Base de Données & Mémoire des Réparations',
    searchHistoryPlaceholder: 'Rechercher par marque, modèle ou panne (ex: iPhone, Dell, Canon)...',
    filterAll: 'Tous',
    filterPhones: 'Téléphones',
    filterComputers: 'Ordinateurs',
    filterTablets: 'Tablettes',
    filterCameras: 'Appareils Photo',
    filterConsoles: 'Consoles de Jeu',
    noHistoryFound: 'Aucun historique ne correspond à votre recherche.',
    adSectionTitle: 'Espace Annonces & Publicités',
    adSectionSubtitle: 'Promouvez votre atelier de réparation ou vente de pièces à l\'international.',
    publishAdButton: 'Publier une Annonce (1.000 Kz)',
    adPriceNotice: 'Tarif fixe : 1.000 KZ (ou équivalent en monnaie internationale USD, EUR, BRL)',
    ibanPaymentTitle: 'Paiement via IBAN Angola :',
    visaPaymentTitle: 'Paiement via Carte Visa Internationale :',
    adFormTitle: 'Formulaire de Publication d\'Annonce',
    businessName: 'Nom de votre Entreprise / Atelier',
    adTitle: 'Titre de l\'Annonce',
    adDescription: 'Description de vos produits ou services',
    contactWhatsApp: 'Contact (Téléphone / WhatsApp avec indicatif pays)',
    websiteOptional: 'Site Web ou Réseau Social (optionnel)',
    paymentMethodSelect: 'Mode de Paiement Utilisé',
    txRefLabel: 'Référence du Paiement / Reçu',
    submitAdButton: 'Soumettre l\'Annonce pour Publication',
    adSuccessMsg: 'Annonce enregistrée avec succès ! Elle est maintenant visible dans l\'application.',
    freeAppBadge: '100% Gratuit pour tous les utilisateurs',
    accessibilityNotice: 'Conçu pour une accessibilité facile à tout âge et quel que soit le niveau de lecture.',
    audioNarrationActive: 'Narration vocale active. Appuyez sur ENTRÉE pour mettre en pause.',
    clearHistory: 'Effacer l\'Historique',
    reopenGuide: 'Ouvrir le Guide',
  }
};
