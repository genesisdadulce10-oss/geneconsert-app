import React from 'react';
import { Volume2, ShieldCheck, Heart, Sparkles, HelpCircle } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../i18n';

interface AccessibilityFooterProps {
  language: Language;
}

export const AccessibilityFooter: React.FC<AccessibilityFooterProps> = ({ language }) => {
  const t = translations[language];

  return (
    <footer className="w-full mt-12 border-t border-gray-500/20 py-8 text-xs text-center opacity-85">
      <div className="max-w-7xl mx-auto px-4 space-y-3">
        
        <div className="flex flex-wrap justify-center items-center gap-4 text-xs font-semibold">
          <span className="flex items-center space-x-1.5 text-emerald-400">
            <ShieldCheck className="w-4 h-4" />
            <span>100% Gratuito & Acessível</span>
          </span>

          <span>•</span>

          <span className="flex items-center space-x-1.5 text-amber-300">
            <Volume2 className="w-4 h-4" />
            <span>Narração de Áudio Ativada por Tecla ENTER</span>
          </span>

          <span>•</span>

          <span className="flex items-center space-x-1.5 text-blue-400">
            <Sparkles className="w-4 h-4" />
            <span>Reconhecimento Automático de Marca & Modelo</span>
          </span>
        </div>

        <p className="max-w-2xl mx-auto text-[11px] opacity-70">
          {t.accessibilityNotice} Desenvolvido para permitir que qualquer pessoa conserte telemóveis, computadores, tablets e câmeras profissionais com facilidade.
        </p>

        <p className="text-[10px] font-mono opacity-50">
          Geneconsert © 2026 • IBAN: AO06.0055.0000.9505.7804.1018.4 • Visa Internacional: 4938755414283232
        </p>

      </div>
    </footer>
  );
};
