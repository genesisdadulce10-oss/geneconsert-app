import React, { useState, useEffect } from 'react';
import { Search, History, Wrench, Clock, Trash2, ArrowRight, Smartphone, Laptop, Tablet, Camera, Gamepad2, Database, RefreshCw } from 'lucide-react';
import { RepairDiagnosis, DeviceCategory, Language } from '../types';
import { translations } from '../i18n';

interface HistoryViewProps {
  language: Language;
  onSelectDiagnosis: (diagnosis: RepairDiagnosis) => void;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  language,
  onSelectDiagnosis,
}) => {
  const t = translations[language];

  const [repairs, setRepairs] = useState<RepairDiagnosis[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  useEffect(() => {
    fetchRepairs();
  }, [searchQuery, selectedCategory]);

  const fetchRepairs = async () => {
    try {
      setLoading(true);
      const url = new URL('/api/repairs', window.location.origin);
      if (searchQuery) url.searchParams.set('q', searchQuery);
      if (selectedCategory !== 'all') url.searchParams.set('category', selectedCategory);

      const res = await fetch(url.toString());
      if (res.ok) {
        const data = await res.json();
        setRepairs(data);
      }
    } catch (err) {
      console.error('Error fetching repair history:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const res = await fetch(`/api/repairs/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setRepairs((prev) => prev.filter((r) => r.id !== id));
      }
    } catch (err) {
      console.error('Error deleting repair history:', err);
    }
  };

  const getCategoryIcon = (category: DeviceCategory) => {
    switch (category) {
      case 'phone': return <Smartphone className="w-5 h-5 text-blue-400" />;
      case 'computer': return <Laptop className="w-5 h-5 text-indigo-400" />;
      case 'tablet': return <Tablet className="w-5 h-5 text-purple-400" />;
      case 'camera': return <Camera className="w-5 h-5 text-emerald-400" />;
      case 'console': return <Gamepad2 className="w-5 h-5 text-amber-400" />;
      default: return <Wrench className="w-5 h-5 text-gray-400" />;
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">

      {/* Header Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-blue-600/10 via-indigo-600/10 to-purple-600/10 border border-blue-500/20">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-blue-500/20 rounded-2xl text-blue-400 font-bold shrink-0">
            <Database className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black tracking-tight font-mono">
              {t.historyTitle}
            </h2>
            <p className="text-xs opacity-80 mt-1">
              Todas as pesquisas e diagnósticos anteriores ficam guardados na memória da base de dados. Pode reutilizá-los quando quiser.
            </p>
          </div>
        </div>
      </div>

      {/* Search & Category Filter Controls */}
      <div className="space-y-4">
        
        {/* Search Input */}
        <div className="relative">
          <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 opacity-50" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.searchHistoryPlaceholder}
            className="w-full pl-12 pr-4 py-3.5 rounded-2xl bg-gray-500/10 border border-gray-500/20 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 font-sans"
          />
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              selectedCategory === 'all'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-gray-500/10 hover:bg-gray-500/20 opacity-70'
            }`}
          >
            {t.filterAll}
          </button>
          <button
            onClick={() => setSelectedCategory('phone')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              selectedCategory === 'phone'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-gray-500/10 hover:bg-gray-500/20 opacity-70'
            }`}
          >
            {t.filterPhones}
          </button>
          <button
            onClick={() => setSelectedCategory('computer')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              selectedCategory === 'computer'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-gray-500/10 hover:bg-gray-500/20 opacity-70'
            }`}
          >
            {t.filterComputers}
          </button>
          <button
            onClick={() => setSelectedCategory('tablet')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              selectedCategory === 'tablet'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-gray-500/10 hover:bg-gray-500/20 opacity-70'
            }`}
          >
            {t.filterTablets}
          </button>
          <button
            onClick={() => setSelectedCategory('camera')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              selectedCategory === 'camera'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-gray-500/10 hover:bg-gray-500/20 opacity-70'
            }`}
          >
            {t.filterCameras}
          </button>
        </div>

      </div>

      {/* History Grid */}
      {loading ? (
        <div className="py-12 text-center text-sm opacity-75 flex flex-col items-center space-y-3">
          <RefreshCw className="w-8 h-8 animate-spin text-blue-500" />
          <span>A carregar base de dados de reparações...</span>
        </div>
      ) : repairs.length === 0 ? (
        <div className="py-12 text-center border-2 border-dashed border-gray-500/20 rounded-3xl p-8 space-y-3">
          <History className="w-12 h-12 mx-auto text-gray-500 opacity-50" />
          <h3 className="text-base font-bold">{t.noHistoryFound}</h3>
          <p className="text-xs opacity-70 max-w-sm mx-auto">
            Faça uma nova pesquisa ou carregue uma foto na aba "Consertar Agora".
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {repairs.map((repair) => (
            <div
              key={repair.id}
              onClick={() => onSelectDiagnosis(repair)}
              className="p-5 rounded-3xl bg-gray-500/5 hover:bg-gray-500/10 border border-gray-500/20 transition-all duration-200 cursor-pointer group hover:scale-[1.01] shadow-sm hover:shadow-md relative overflow-hidden flex flex-col justify-between"
            >
              <div>
                
                {/* Top Badge Row */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <div className="p-2 bg-gray-500/10 rounded-xl">
                      {getCategoryIcon(repair.deviceCategory)}
                    </div>
                    <span className="text-xs font-black uppercase tracking-wider text-blue-400">
                      {repair.brand}
                    </span>
                  </div>

                  <button
                    onClick={(e) => handleDelete(repair.id, e)}
                    className="p-2 text-gray-500 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-colors"
                    title="Eliminar do Histórico"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Device Title & Issue */}
                <h3 className="text-lg font-extrabold tracking-tight group-hover:text-blue-400 transition-colors">
                  {repair.model}
                </h3>

                <p className="text-xs opacity-80 mt-1 line-clamp-2 font-medium">
                  {repair.issueSummary}
                </p>

              </div>

              {/* Footer Meta */}
              <div className="pt-4 mt-4 border-t border-gray-500/15 flex items-center justify-between text-xs font-bold">
                <span className="opacity-60 text-[11px]">
                  {new Date(repair.createdAt).toLocaleDateString()}
                </span>

                <span className="text-emerald-400 font-extrabold flex items-center space-x-1 group-hover:translate-x-1 transition-transform">
                  <span>{t.reopenGuide}</span>
                  <ArrowRight className="w-4 h-4" />
                </span>
              </div>

            </div>
          ))}
        </div>
      )}

    </div>
  );
};
