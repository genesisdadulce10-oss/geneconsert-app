import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, ShieldAlert, Wrench, Clock, AlertTriangle, ArrowLeft, CheckCircle, Eye, Sparkles, HelpCircle, Cpu } from 'lucide-react';
import { RepairDiagnosis, RepairStep, Language } from '../types';
import { translations } from '../i18n';

interface RepairGuideViewProps {
  diagnosis: RepairDiagnosis;
  language: Language;
  onBack: () => void;
  setAudioActive: (active: boolean) => void;
}

export const RepairGuideView: React.FC<RepairGuideViewProps> = ({
  diagnosis,
  language,
  onBack,
  setAudioActive,
}) => {
  const t = translations[language];

  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(true);
  const [audioSpeed, setAudioSpeed] = useState<number>(1);
  const [simplifiedMode, setSimplifiedMode] = useState<boolean>(false);
  const [speechSupported, setSpeechSupported] = useState<boolean>(true);

  const speechUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  const currentStep: RepairStep = diagnosis.steps[currentStepIndex] || diagnosis.steps[0];

  // Speech Synthesis setup
  useEffect(() => {
    if (!('speechSynthesis' in window)) {
      setSpeechSupported(false);
      return;
    }

    // Auto-play initial step audio on load
    speakStepText(currentStep.spokenNarration || currentStep.description);

    return () => {
      window.speechSynthesis.cancel();
      setAudioActive(false);
    };
  }, [currentStepIndex]);

  // Keyboard listener for ENTER to play/pause audio or advance steps
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        togglePlayPause();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlayingAudio, currentStepIndex]);

  // Speak function
  const speakStepText = (text: string) => {
    if (!('speechSynthesis' in window)) return;

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    
    // Set language code
    const langMap: Record<Language, string> = {
      pt: 'pt-PT',
      en: 'en-US',
      es: 'es-ES',
      fr: 'fr-FR',
    };
    utterance.lang = langMap[language] || 'pt-PT';
    utterance.rate = audioSpeed;

    utterance.onstart = () => {
      setIsPlayingAudio(true);
      setAudioActive(true);
    };

    utterance.onend = () => {
      setIsPlayingAudio(false);
      setAudioActive(false);
    };

    utterance.onerror = (e) => {
      console.error('Speech synthesis error:', e);
      setIsPlayingAudio(false);
      setAudioActive(false);
    };

    speechUtteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  };

  const togglePlayPause = () => {
    if (!('speechSynthesis' in window)) return;

    if (isPlayingAudio) {
      window.speechSynthesis.pause();
      setIsPlayingAudio(false);
      setAudioActive(false);
    } else {
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
        setIsPlayingAudio(true);
        setAudioActive(true);
      } else {
        speakStepText(currentStep.spokenNarration || currentStep.description);
      }
    }
  };

  const handleNextStep = () => {
    if (currentStepIndex < diagnosis.steps.length - 1) {
      setCurrentStepIndex((prev) => prev + 1);
    }
  };

  const handlePrevStep = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex((prev) => prev - 1);
    }
  };

  // Icon mapping for action types
  const getActionBadge = (action: string) => {
    switch (action) {
      case 'unscrew':
        return { label: 'Desparafusar / Soltar', icon: '🪛', color: 'bg-amber-500/20 text-amber-400 border-amber-500/30' };
      case 'disconnect':
        return { label: 'Desconectar Cabo / Bateria', icon: '🔌', color: 'bg-red-500/20 text-red-400 border-red-500/30' };
      case 'heat':
        return { label: 'Aquecer Cola da Tela', icon: '♨️', color: 'bg-orange-500/20 text-orange-400 border-orange-500/30' };
      case 'replace':
        return { label: 'Substituir Peça Nova', icon: '🔄', color: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' };
      case 'clean':
        return { label: 'Limpeza de Poeira / Álcool', icon: '🧼', color: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30' };
      case 'test':
        return { label: 'Testar Funcionamento', icon: '⚡', color: 'bg-purple-500/20 text-purple-400 border-purple-500/30' };
      default:
        return { label: 'Inspecionar Aparelho', icon: '🔍', color: 'bg-blue-500/20 text-blue-400 border-blue-500/30' };
    }
  };

  // Custom visual component diagram rendering
  const renderVisualIllustration = (type: string) => {
    return (
      <div className="w-full h-56 sm:h-72 bg-gradient-to-b from-gray-900 via-gray-950 to-black rounded-3xl border border-gray-800 p-6 flex flex-col items-center justify-center relative overflow-hidden shadow-2xl">
        
        {/* Background circuit grid overlay */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#3b82f6_1px,transparent_1px)] [background-size:16px_16px]" />

        {/* Dynamic Graphic representation according to step illustration type */}
        {type === 'screen' ? (
          <div className="relative z-10 flex flex-col items-center">
            <div className="w-36 h-52 rounded-2xl border-4 border-blue-500 bg-blue-950/60 p-2 flex flex-col items-center justify-between shadow-blue-500/20 shadow-2xl animate-pulse">
              <div className="w-12 h-1.5 rounded-full bg-blue-400/60 mb-2" />
              <div className="text-center">
                <span className="text-4xl block">📱</span>
                <span className="text-[11px] font-mono text-blue-300 font-bold mt-1 block">PAINEL DISPLAY OLED</span>
              </div>
              <div className="w-8 h-8 rounded-full border border-blue-400/60" />
            </div>
            <span className="mt-3 text-xs font-mono text-blue-400 font-semibold bg-blue-900/50 px-3 py-1 rounded-full border border-blue-500/30">
              Descaixar a tela com cuidado
            </span>
          </div>
        ) : type === 'battery' ? (
          <div className="relative z-10 flex flex-col items-center">
            <div className="w-44 h-32 rounded-2xl border-4 border-red-500 bg-red-950/60 p-3 flex flex-col justify-between shadow-red-500/20 shadow-2xl">
              <div className="flex justify-between items-center text-xs font-mono text-red-300 font-bold">
                <span>BATTERIA LITHIUM</span>
                <span className="px-2 py-0.5 bg-red-500 text-black rounded font-black text-[10px]">CUIDADO</span>
              </div>
              <div className="text-center py-2">
                <span className="text-4xl block">🔋</span>
              </div>
              <div className="w-full h-2 bg-red-900 rounded-full overflow-hidden">
                <div className="w-3/4 h-full bg-red-500" />
              </div>
            </div>
            <span className="mt-3 text-xs font-mono text-red-400 font-semibold bg-red-900/50 px-3 py-1 rounded-full border border-red-500/30">
              Desconectar o cabo da bateria em primeiro lugar!
            </span>
          </div>
        ) : type === 'motherboard' ? (
          <div className="relative z-10 flex flex-col items-center">
            <div className="w-56 h-36 rounded-2xl border-4 border-emerald-500 bg-emerald-950/60 p-4 flex flex-col justify-between shadow-emerald-500/20 shadow-2xl">
              <div className="flex justify-between items-center text-xs font-mono text-emerald-300 font-bold">
                <span>PLACA-MÃE PRINCIPAL</span>
                <Cpu className="w-5 h-5 text-emerald-400" />
              </div>
              <div className="flex justify-around items-center my-1">
                <div className="w-8 h-8 rounded bg-emerald-800 border border-emerald-400 flex items-center justify-center font-mono text-[10px] text-emerald-200">CPU</div>
                <div className="w-10 h-6 rounded bg-blue-800 border border-blue-400 flex items-center justify-center font-mono text-[10px] text-blue-200">RAM</div>
                <div className="w-8 h-8 rounded bg-amber-800 border border-amber-400 flex items-center justify-center font-mono text-[10px] text-amber-200">CHIP</div>
              </div>
              <span className="text-[10px] text-emerald-400/80 font-mono text-center">Conectores Flex & Circuitos Integrados</span>
            </div>
            <span className="mt-3 text-xs font-mono text-emerald-400 font-semibold bg-emerald-900/50 px-3 py-1 rounded-full border border-emerald-500/30">
              Manusear conectores com espátula plástica
            </span>
          </div>
        ) : type === 'camera_lens' ? (
          <div className="relative z-10 flex flex-col items-center">
            <div className="w-40 h-40 rounded-full border-4 border-purple-500 bg-purple-950/60 p-4 flex flex-col items-center justify-center shadow-purple-500/20 shadow-2xl">
              <span className="text-5xl block">📷</span>
              <span className="text-[10px] font-mono text-purple-300 font-bold mt-2">SENSOR & LENTE</span>
            </div>
            <span className="mt-3 text-xs font-mono text-purple-400 font-semibold bg-purple-900/50 px-3 py-1 rounded-full border border-purple-500/30">
              Limpar vidro da lente sem encostar no sensor
            </span>
          </div>
        ) : (
          <div className="relative z-10 flex flex-col items-center">
            <div className="w-48 h-36 rounded-2xl border-4 border-amber-500 bg-amber-950/60 p-4 flex flex-col items-center justify-center shadow-amber-500/20 shadow-2xl">
              <span className="text-5xl block">🛠️</span>
              <span className="text-xs font-mono text-amber-300 font-bold mt-2">FERRAMENTAS & PARAFUSOS</span>
            </div>
            <span className="mt-3 text-xs font-mono text-amber-400 font-semibold bg-amber-900/50 px-3 py-1 rounded-full border border-amber-500/30">
              Organizar parafusos por ordem de remoção
            </span>
          </div>
        )}

        {/* Live Step Badge overlay */}
        <div className="absolute bottom-3 right-4 bg-black/80 text-white px-3 py-1 rounded-xl text-[11px] font-mono border border-gray-700">
          Ilustração do Passo #{currentStep.stepNumber}
        </div>

      </div>
    );
  };

  const actionInfo = getActionBadge(currentStep.actionType);

  return (
    <div className="max-w-5xl mx-auto space-y-6">

      {/* Back Button & Device Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-gray-500/5 border border-gray-500/20">
        
        <div className="flex items-center space-x-3">
          <button
            onClick={onBack}
            className="p-3 rounded-2xl bg-gray-500/10 hover:bg-gray-500/20 transition-all text-sm font-bold flex items-center space-x-2"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="hidden sm:inline">Voltar ao Início</span>
          </button>

          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-blue-500/20 text-blue-400 border border-blue-500/30 uppercase">
                {diagnosis.brand}
              </span>
              <h2 className="text-xl font-black tracking-tight font-mono">
                {diagnosis.model}
              </h2>
            </div>
            <p className="text-xs opacity-80 mt-1 font-medium">
              {t.detectedProblem} <strong className="text-blue-400">{diagnosis.issueSummary}</strong>
            </p>
          </div>
        </div>

        {/* Meta badges: Difficulty & Time */}
        <div className="flex items-center space-x-2 text-xs font-bold">
          <span className="px-3 py-1.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30 flex items-center space-x-1">
            <Wrench className="w-3.5 h-3.5" />
            <span>{t.difficultyLabel} {diagnosis.difficulty}</span>
          </span>
          <span className="px-3 py-1.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center space-x-1">
            <Clock className="w-3.5 h-3.5" />
            <span>{diagnosis.estimatedTime}</span>
          </span>
        </div>

      </div>

      {/* Required Tools & Safety Instructions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Tools */}
        <div className="p-5 rounded-3xl bg-gray-500/5 border border-gray-500/20">
          <h3 className="text-sm font-extrabold flex items-center space-x-2 mb-3">
            <Wrench className="w-4 h-4 text-blue-400" />
            <span>{t.toolsNeededTitle}</span>
          </h3>
          <ul className="flex flex-wrap gap-2">
            {diagnosis.toolsNeeded.map((tool, idx) => (
              <li key={idx} className="px-3 py-1 rounded-xl bg-blue-500/10 border border-blue-500/20 text-xs font-medium">
                🛠️ {tool}
              </li>
            ))}
          </ul>
        </div>

        {/* Safety Tips */}
        <div className="p-5 rounded-3xl bg-amber-500/5 border border-amber-500/20">
          <h3 className="text-sm font-extrabold flex items-center space-x-2 mb-3 text-amber-400">
            <ShieldAlert className="w-4 h-4" />
            <span>{t.safetyTitle}</span>
          </h3>
          <ul className="space-y-1.5 text-xs opacity-90">
            {diagnosis.safetyTips.map((tip, idx) => (
              <li key={idx} className="flex items-start space-x-2">
                <span className="text-amber-400 font-bold">•</span>
                <span>{tip}</span>
              </li>
            ))}
          </ul>
        </div>

      </div>

      {/* AUDIO PLAYER & ACCESSIBILITY BAR */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-blue-600/15 via-indigo-600/15 to-emerald-600/15 border-2 border-blue-500/30 space-y-4 shadow-xl">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          
          <div className="flex items-center space-x-3">
            <div className={`p-3 rounded-2xl ${isPlayingAudio ? 'bg-emerald-500 text-white animate-bounce-slow' : 'bg-blue-500/20 text-blue-400'}`}>
              <Volume2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-black tracking-tight">
                {t.audioPlayerTitle}
              </h3>
              <p className="text-xs opacity-80">
                Pressione a tecla ENTER ou use os botões abaixo para ouvir e acompanhar as instruções em voz.
              </p>
            </div>
          </div>

          {/* Toggle Simplified Mode for Low Literacy / Accessibility */}
          <button
            onClick={() => setSimplifiedMode(!simplifiedMode)}
            className={`px-4 py-2 rounded-2xl text-xs font-bold transition-all border flex items-center space-x-2 ${
              simplifiedMode
                ? 'bg-amber-500 text-black border-amber-400 shadow-lg'
                : 'bg-gray-500/10 hover:bg-gray-500/20 border-gray-500/30'
            }`}
          >
            <Eye className="w-4 h-4" />
            <span>{t.simplifiedMode}</span>
          </button>

        </div>

        {/* Audio Controls Bar */}
        <div className="flex flex-wrap items-center justify-between bg-black/40 p-3 rounded-2xl border border-white/10 gap-3">
          
          {/* Prev / Play / Next */}
          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrevStep}
              disabled={currentStepIndex === 0}
              className={`p-2.5 rounded-xl border font-bold text-xs ${
                currentStepIndex === 0 ? 'opacity-40 cursor-not-allowed border-gray-700' : 'bg-gray-800 hover:bg-gray-700 border-gray-600'
              }`}
              title={t.prevStep}
            >
              <SkipBack className="w-5 h-5 text-white" />
            </button>

            {/* BIG PLAY/PAUSE ENTER BUTTON */}
            <button
              onClick={togglePlayPause}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-extrabold text-sm shadow-lg flex items-center space-x-2 border border-emerald-400/30"
            >
              {isPlayingAudio ? (
                <>
                  <Pause className="w-5 h-5 fill-current" />
                  <span>{t.pauseAudio} (ENTER)</span>
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 fill-current ml-0.5" />
                  <span>{t.playAudio} (ENTER)</span>
                </>
              )}
            </button>

            <button
              onClick={handleNextStep}
              disabled={currentStepIndex === diagnosis.steps.length - 1}
              className={`p-2.5 rounded-xl border font-bold text-xs ${
                currentStepIndex === diagnosis.steps.length - 1 ? 'opacity-40 cursor-not-allowed border-gray-700' : 'bg-gray-800 hover:bg-gray-700 border-gray-600'
              }`}
              title={t.nextStep}
            >
              <SkipForward className="w-5 h-5 text-white" />
            </button>
          </div>

          {/* Speed Selector */}
          <div className="flex items-center space-x-2 text-xs font-bold text-gray-300">
            <span>{t.speedLabel}</span>
            <button
              onClick={() => { setAudioSpeed(0.8); speakStepText(currentStep.spokenNarration || currentStep.description); }}
              className={`px-2 py-1 rounded-lg ${audioSpeed === 0.8 ? 'bg-blue-600 text-white' : 'bg-gray-800 hover:bg-gray-700'}`}
            >
              0.8x
            </button>
            <button
              onClick={() => { setAudioSpeed(1); speakStepText(currentStep.spokenNarration || currentStep.description); }}
              className={`px-2 py-1 rounded-lg ${audioSpeed === 1 ? 'bg-blue-600 text-white' : 'bg-gray-800 hover:bg-gray-700'}`}
            >
              1.0x
            </button>
            <button
              onClick={() => { setAudioSpeed(1.25); speakStepText(currentStep.spokenNarration || currentStep.description); }}
              className={`px-2 py-1 rounded-lg ${audioSpeed === 1.25 ? 'bg-blue-600 text-white' : 'bg-gray-800 hover:bg-gray-700'}`}
            >
              1.25x
            </button>
          </div>

        </div>

      </div>

      {/* STEP DISPLAY CAROUSEL */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gray-500/5 border border-gray-500/20 space-y-6">
        
        {/* Step Progress Bar */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-bold">
            <span className="text-blue-400 font-mono uppercase tracking-widest">
              Passo {currentStepIndex + 1} de {diagnosis.steps.length}
            </span>
            <span className="px-3 py-1 rounded-full text-[11px] font-bold border ${actionInfo.color}">
              {actionInfo.icon} {actionInfo.label}
            </span>
          </div>

          <div className="w-full h-3 bg-gray-500/20 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-blue-500 via-emerald-500 to-teal-400 transition-all duration-300"
              style={{ width: `${((currentStepIndex + 1) / diagnosis.steps.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Step Title & Content */}
        <div>
          <h3 className="text-2xl font-black tracking-tight mb-2 flex items-center space-x-2">
            <span className="w-8 h-8 rounded-xl bg-blue-500 text-white flex items-center justify-center text-sm font-mono shrink-0">
              {currentStep.stepNumber}
            </span>
            <span>{currentStep.title}</span>
          </h3>

          <p className={`text-base sm:text-lg leading-relaxed ${simplifiedMode ? 'font-black text-amber-300 text-xl' : 'opacity-90 font-sans'}`}>
            {currentStep.description}
          </p>
        </div>

        {/* Spoken Narration Quote Box */}
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-1">
          <div className="text-[11px] font-bold text-emerald-400 uppercase tracking-widest flex items-center space-x-1">
            <Volume2 className="w-3.5 h-3.5" />
            <span>Voz de Orientação (Áudio de Leitura Fácil):</span>
          </div>
          <p className="text-sm font-semibold italic text-emerald-200">
            "{currentStep.spokenNarration || currentStep.description}"
          </p>
        </div>

        {/* Visual Graphic Illustration */}
        {renderVisualIllustration(currentStep.illustrationType || 'tools')}

        {currentStep.warningNote && (
          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold flex items-start space-x-2">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <span><strong>Atenção:</strong> {currentStep.warningNote}</span>
          </div>
        )}

        {/* Step Navigation Controls */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-500/20">
          <button
            onClick={handlePrevStep}
            disabled={currentStepIndex === 0}
            className={`px-5 py-3 rounded-2xl font-bold text-sm transition-all flex items-center space-x-2 ${
              currentStepIndex === 0
                ? 'opacity-30 cursor-not-allowed bg-gray-500/10'
                : 'bg-gray-500/20 hover:bg-gray-500/30'
            }`}
          >
            <SkipBack className="w-4 h-4" />
            <span>Passo Anterior</span>
          </button>

          <button
            onClick={handleNextStep}
            disabled={currentStepIndex === diagnosis.steps.length - 1}
            className={`px-6 py-3 rounded-2xl font-extrabold text-sm transition-all flex items-center space-x-2 text-white shadow-lg ${
              currentStepIndex === diagnosis.steps.length - 1
                ? 'bg-emerald-600 opacity-70 cursor-not-allowed'
                : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500'
            }`}
          >
            <span>Próximo Passo</span>
            <SkipForward className="w-4 h-4" />
          </button>
        </div>

      </div>

    </div>
  );
};
