import React from 'react';
import { Wrench, Cpu, Moon, Sun, Globe, Volume2, ShieldCheck, History, Megaphone, PlusCircle, MinusCircle, Sparkles } from 'lucide-react';
import { ThemeMode, Language } from '../types';
import { translations } from '../i18n';

interface HeaderProps {
  theme: ThemeMode;
  setTheme: (mode: ThemeMode) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  activeTab: 'scan' | 'history' | 'ads';
  setActiveTab: (tab: 'scan' | 'history' | 'ads') => void;
  fontSize: 'normal' | 'large' | 'xlarge';
  setFontSize: (size: 'normal' | 'large' | 'xlarge') => void;
  audioActive: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  theme,
  setTheme,
  language,
  setLanguage,
  activeTab,
  setActiveTab,
  fontSize,
  setFontSize,
  audioActive,
}) => {
  const t = translations[language];

  // Theme style helpers based on selected background theme
  const getThemeBadgeBg = (mode: ThemeMode) => {
    switch (mode) {
      case 'white': return 'bg-gray-100 text-gray-800 border-gray-300';
      case 'black': return 'bg-gray-900 text-white border-gray-700';
      case 'blue': return 'bg-blue-900 text-blue-100 border-blue-700';
      case 'green': return 'bg-emerald-900 text-emerald-100 border-emerald-700';
    }
  };

  return (
    <header className="w-full border-b transition-colors duration-200 shadow-sm sticky top-0 z-40 backdrop-blur-md bg-opacity-95 bg-inherit">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top bar: Accessibility, Language, and Theme selector */}
        <div className="py-2.5 flex flex-wrap items-center justify-between border-b border-gray-200/20 text-xs sm:text-sm gap-2">
          
          {/* Free Badge & Audio Indicator */}
          <div className="flex items-center space-x-3">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
              <ShieldCheck className="w-3.5 h-3.5 mr-1" />
              {t.freeAppBadge}
            </span>

            {audioActive && (
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-amber-500/20 text-amber-600 dark:text-amber-400 animate-pulse">
                <Volume2 className="w-3.5 h-3.5 mr-1" />
                Áudio Ativo (ENTER)
              </span>
            )}
          </div>

          {/* Controls: Font Size, Language, Theme Modes */}
          <div className="flex flex-wrap items-center space-x-2 sm:space-x-4">
            
            {/* Font Size Adjuster for Accessibility */}
            <div className="flex items-center space-x-1 border-r border-gray-400/30 pr-3">
              <span className="text-xs opacity-75 font-medium hidden sm:inline">Texto:</span>
              <button
                onClick={() => setFontSize('normal')}
                className={`px-1.5 py-0.5 rounded text-xs font-bold ${fontSize === 'normal' ? 'bg-blue-600 text-white' : 'opacity-70 hover:opacity-100'}`}
                title="Tamanho Normal"
              >
                A
              </button>
              <button
                onClick={() => setFontSize('large')}
                className={`px-1.5 py-0.5 rounded text-sm font-bold ${fontSize === 'large' ? 'bg-blue-600 text-white' : 'opacity-70 hover:opacity-100'}`}
                title="Tamanho Grande"
              >
                A+
              </button>
              <button
                onClick={() => setFontSize('xlarge')}
                className={`px-1.5 py-0.5 rounded text-base font-bold ${fontSize === 'xlarge' ? 'bg-blue-600 text-white' : 'opacity-70 hover:opacity-100'}`}
                title="Tamanho Extra Grande"
              >
                A++
              </button>
            </div>

            {/* Language Switcher */}
            <div className="flex items-center space-x-1 border-r border-gray-400/30 pr-3">
              <Globe className="w-3.5 h-3.5 opacity-70" />
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as Language)}
                className="bg-transparent text-xs font-semibold py-0.5 px-1 rounded cursor-pointer focus:outline-none focus:ring-1 focus:ring-blue-500"
              >
                <option value="pt" className="text-gray-900">🇵🇹 PT</option>
                <option value="en" className="text-gray-900">🇬🇧 EN</option>
                <option value="es" className="text-gray-900">🇪🇸 ES</option>
                <option value="fr" className="text-gray-900">🇫🇷 FR</option>
              </select>
            </div>

            {/* Background Theme Mode Controls (Branca, Preto, Azul, Verde) */}
            <div className="flex items-center space-x-1.5">
              <span className="text-xs opacity-75 font-medium hidden sm:inline">Fundo:</span>
              
              <button
                onClick={() => setTheme('white')}
                className={`w-6 h-6 rounded-full border-2 transition-all ${theme === 'white' ? 'ring-2 ring-blue-500 scale-110 border-gray-400' : 'border-gray-300 opacity-80'}`}
                style={{ backgroundColor: '#ffffff' }}
                title={t.themeWhite}
              />
              <button
                onClick={() => setTheme('black')}
                className={`w-6 h-6 rounded-full border-2 transition-all ${theme === 'black' ? 'ring-2 ring-blue-400 scale-110 border-white' : 'border-gray-700 opacity-80'}`}
                style={{ backgroundColor: '#090d16' }}
                title={t.themeBlack}
              />
              <button
                onClick={() => setTheme('blue')}
                className={`w-6 h-6 rounded-full border-2 transition-all ${theme === 'blue' ? 'ring-2 ring-yellow-400 scale-110 border-white' : 'border-blue-700 opacity-80'}`}
                style={{ backgroundColor: '#0f172a' }}
                title={t.themeBlue}
              />
              <button
                onClick={() => setTheme('green')}
                className={`w-6 h-6 rounded-full border-2 transition-all ${theme === 'green' ? 'ring-2 ring-emerald-300 scale-110 border-white' : 'border-emerald-700 opacity-80'}`}
                style={{ backgroundColor: '#062c1b' }}
                title={t.themeGreen}
              />
            </div>

          </div>
        </div>

        {/* Main Logo and Navigation Tabs */}
        <div className="py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Brand & Logo */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('scan')}>
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-emerald-500 p-0.5 shadow-lg flex items-center justify-center text-white">
              <div className="w-full h-full bg-gray-900/90 rounded-[14px] flex items-center justify-center">
                <Wrench className="w-6 h-6 text-emerald-400 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-2xl font-black tracking-tight font-mono text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-emerald-400 to-indigo-300">
                  {t.appName}
                </h1>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400 uppercase tracking-widest border border-blue-500/30">
                  AI REPAIR
                </span>
              </div>
              <p className="text-xs opacity-80 max-w-md line-clamp-1 font-medium">
                {t.tagline}
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center bg-gray-500/10 p-1.5 rounded-2xl border border-gray-500/20 space-x-1 sm:space-x-2">
            <button
              onClick={() => setActiveTab('scan')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl font-bold text-sm transition-all ${
                activeTab === 'scan'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md'
                  : 'opacity-70 hover:opacity-100 hover:bg-gray-500/10'
              }`}
            >
              <Wrench className="w-4 h-4" />
              <span>{t.tabFixNow}</span>
            </button>

            <button
              onClick={() => setActiveTab('history')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl font-bold text-sm transition-all ${
                activeTab === 'history'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md'
                  : 'opacity-70 hover:opacity-100 hover:bg-gray-500/10'
              }`}
            >
              <History className="w-4 h-4" />
              <span>{t.tabHistory}</span>
            </button>

            <button
              onClick={() => setActiveTab('ads')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-xl font-bold text-sm transition-all ${
                activeTab === 'ads'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
                  : 'opacity-70 hover:opacity-100 hover:bg-gray-500/10'
              }`}
            >
              <Megaphone className="w-4 h-4" />
              <span>{t.tabAds}</span>
              <span className="ml-1 text-[10px] px-1.5 py-0.2 rounded bg-amber-400 text-black font-extrabold">
                1.000 Kz
              </span>
            </button>
          </nav>

        </div>

      </div>
    </header>
  );
};
