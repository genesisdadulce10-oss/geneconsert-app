import React, { useState, useEffect } from 'react';
import { Megaphone, CreditCard, Send, CheckCircle2, ShieldCheck, ExternalLink, Phone, PlusCircle, Building2, Sparkles, Copy, Check } from 'lucide-react';
import { Advertisement, Language } from '../types';
import { translations } from '../i18n';

interface AdPlatformViewProps {
  language: Language;
}

export const AdPlatformView: React.FC<AdPlatformViewProps> = ({ language }) => {
  const t = translations[language];

  const [ads, setAds] = useState<Advertisement[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [showForm, setShowForm] = useState<boolean>(false);
  const [copiedIban, setCopiedIban] = useState<boolean>(false);
  const [copiedVisa, setCopiedVisa] = useState<boolean>(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    title: '',
    advertiserName: '',
    description: '',
    category: 'pecas' as 'pecas' | 'assistencia' | 'ferramentas' | 'outros',
    contact: '',
    websiteUrl: '',
    imageUrl: '',
    paidAmount: '1.000 KZ',
    paymentMethod: 'iban' as 'iban' | 'visa',
    transactionRef: '',
  });

  const OFFICIAL_IBAN = 'AO06.0055.0000.9505.7804.1018.4';
  const OFFICIAL_VISA = '4938755414283232';

  useEffect(() => {
    fetchAds();
  }, []);

  const fetchAds = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/ads');
      if (res.ok) {
        const data = await res.json();
        setAds(data);
      }
    } catch (err) {
      console.error('Error fetching ads:', err);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string, type: 'iban' | 'visa') => {
    navigator.clipboard.writeText(text);
    if (type === 'iban') {
      setCopiedIban(true);
      setTimeout(() => setCopiedIban(false), 2000);
    } else {
      setCopiedVisa(true);
      setTimeout(() => setCopiedVisa(false), 2000);
    }
  };

  const handleSubmitAd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || !formData.advertiserName || !formData.description || !formData.contact) {
      alert('Por favor preencha todos os campos obrigatórios.');
      return;
    }

    try {
      const res = await fetch('/api/ads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (res.ok) {
        setSuccessMsg(t.adSuccessMsg);
        setShowForm(false);
        fetchAds();
        setFormData({
          title: '',
          advertiserName: '',
          description: '',
          category: 'pecas',
          contact: '',
          websiteUrl: '',
          imageUrl: '',
          paidAmount: '1.000 KZ',
          paymentMethod: 'iban',
          transactionRef: '',
        });
      }
    } catch (err) {
      console.error('Error submitting ad:', err);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">

      {/* Top Banner introducing Ad Platform */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-emerald-600/15 via-teal-600/15 to-blue-600/15 border-2 border-emerald-500/30 text-left space-y-4 shadow-xl">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-emerald-500/20 rounded-2xl text-emerald-400 font-bold shrink-0">
              <Megaphone className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-400 text-black uppercase tracking-widest">
                  PROMOÇÃO E PROPAGANDA
                </span>
                <h2 className="text-xl font-black tracking-tight font-mono">
                  {t.adSectionTitle}
                </h2>
              </div>
              <p className="text-xs opacity-90 mt-1 max-w-xl">
                {t.adSectionSubtitle}
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowForm(!showForm)}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-black text-sm shadow-lg flex items-center space-x-2 shrink-0 hover:scale-105 transition-all"
          >
            <PlusCircle className="w-5 h-5" />
            <span>{t.publishAdButton}</span>
          </button>
        </div>

        {/* Price & Payment Notice Box */}
        <div className="p-4 rounded-2xl bg-black/40 border border-emerald-500/30 text-xs font-semibold flex items-center justify-between">
          <div className="flex items-center space-x-2 text-emerald-300">
            <Sparkles className="w-4 h-4" />
            <span>{t.adPriceNotice}</span>
          </div>
        </div>

      </div>

      {/* PAYMENT DETAILS SECTION (IBAN & VISA) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* IBAN Card */}
        <div className="p-5 rounded-3xl bg-gray-500/5 border border-gray-500/20 space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-blue-400">
            <span>{t.ibanPaymentTitle}</span>
            <span className="px-2 py-0.5 rounded bg-blue-500/20 text-[10px]">ANGOLA</span>
          </div>

          <div className="flex items-center justify-between bg-black/40 p-3 rounded-2xl border border-white/10">
            <code className="text-xs sm:text-sm font-mono font-bold tracking-wider select-all text-emerald-400">
              {OFFICIAL_IBAN}
            </code>
            <button
              onClick={() => copyToClipboard(OFFICIAL_IBAN, 'iban')}
              className="p-1.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-xs font-bold transition-all flex items-center space-x-1"
              title="Copiar IBAN"
            >
              {copiedIban ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-gray-300" />}
            </button>
          </div>
        </div>

        {/* VISA Card */}
        <div className="p-5 rounded-3xl bg-gray-500/5 border border-gray-500/20 space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-amber-400">
            <span>{t.visaPaymentTitle}</span>
            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-[10px]">INTERNACIONAL</span>
          </div>

          <div className="flex items-center justify-between bg-black/40 p-3 rounded-2xl border border-white/10">
            <code className="text-xs sm:text-sm font-mono font-bold tracking-wider select-all text-amber-300">
              {OFFICIAL_VISA}
            </code>
            <button
              onClick={() => copyToClipboard(OFFICIAL_VISA, 'visa')}
              className="p-1.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-xs font-bold transition-all flex items-center space-x-1"
              title="Copiar Visa"
            >
              {copiedVisa ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-gray-300" />}
            </button>
          </div>
        </div>

      </div>

      {successMsg && (
        <div className="p-4 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-sm font-bold flex items-center space-x-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* AD SUBMISSION FORM MODAL / PANEL */}
      {showForm && (
        <form onSubmit={handleSubmitAd} className="p-6 sm:p-8 rounded-3xl bg-gray-500/10 border-2 border-emerald-500/40 space-y-5">
          
          <div className="flex items-center justify-between border-b border-gray-500/20 pb-4">
            <h3 className="text-lg font-black tracking-tight font-mono flex items-center space-x-2">
              <Building2 className="w-5 h-5 text-emerald-400" />
              <span>{t.adFormTitle}</span>
            </h3>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-500/20 px-3 py-1 rounded-full border border-emerald-500/30">
              Valor: 1.000 KZ
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            <div>
              <label className="block text-xs font-bold mb-1">{t.businessName} *</label>
              <input
                type="text"
                required
                value={formData.advertiserName}
                onChange={(e) => setFormData({ ...formData, advertiserName: e.target.value })}
                placeholder="Ex: Oficina Tech Luanda"
                className="w-full px-4 py-2.5 rounded-xl bg-gray-500/10 border border-gray-500/30 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans"
              />
            </div>

            <div>
              <label className="block text-xs font-bold mb-1">{t.adTitle} *</label>
              <input
                type="text"
                required
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Ex: Venda de Telas Originais iPhone & Samsung"
                className="w-full px-4 py-2.5 rounded-xl bg-gray-500/10 border border-gray-500/30 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans"
              />
            </div>

            <div>
              <label className="block text-xs font-bold mb-1">Categoria do Produto/Serviço *</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value as any })}
                className="w-full px-4 py-2.5 rounded-xl bg-gray-500/10 border border-gray-500/30 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans"
              >
                <option value="pecas" className="text-black">Peças de Reposição & Baterias</option>
                <option value="assistencia" className="text-black">Assistência Técnica de Reparação</option>
                <option value="ferramentas" className="text-black">Ferramentas de Eletrónica</option>
                <option value="outros" className="text-black">Outros Produtos Tecnológicos</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold mb-1">{t.contactWhatsApp} *</label>
              <input
                type="text"
                required
                value={formData.contact}
                onChange={(e) => setFormData({ ...formData, contact: e.target.value })}
                placeholder="Ex: +244 923 000 111"
                className="w-full px-4 py-2.5 rounded-xl bg-gray-500/10 border border-gray-500/30 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans"
              />
            </div>

            <div>
              <label className="block text-xs font-bold mb-1">{t.websiteOptional}</label>
              <input
                type="url"
                value={formData.websiteUrl}
                onChange={(e) => setFormData({ ...formData, websiteUrl: e.target.value })}
                placeholder="https://sualoja.com ou perfil Instagram"
                className="w-full px-4 py-2.5 rounded-xl bg-gray-500/10 border border-gray-500/30 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans"
              />
            </div>

            <div>
              <label className="block text-xs font-bold mb-1">{t.paymentMethodSelect}</label>
              <select
                value={formData.paymentMethod}
                onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value as any })}
                className="w-full px-4 py-2.5 rounded-xl bg-gray-500/10 border border-gray-500/30 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans"
              >
                <option value="iban" className="text-black">IBAN Angola (AO06.0055.0000...)</option>
                <option value="visa" className="text-black">Cartão Visa Internacional (4938...)</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold mb-1">{t.txRefLabel} *</label>
              <input
                type="text"
                required
                value={formData.transactionRef}
                onChange={(e) => setFormData({ ...formData, transactionRef: e.target.value })}
                placeholder="Ex: REF-9948210 ou nº de talão de transferência"
                className="w-full px-4 py-2.5 rounded-xl bg-gray-500/10 border border-gray-500/30 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold mb-1">{t.adDescription} *</label>
              <textarea
                required
                rows={3}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Descreva a sua loja, produtos, marcas atendidas ou serviços de reparação..."
                className="w-full px-4 py-2.5 rounded-xl bg-gray-500/10 border border-gray-500/30 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 font-sans resize-none"
              />
            </div>

          </div>

          <div className="flex justify-end space-x-3 pt-2">
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="px-5 py-2.5 rounded-xl bg-gray-500/20 hover:bg-gray-500/30 font-bold text-xs"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs shadow-lg flex items-center space-x-2"
            >
              <Send className="w-4 h-4" />
              <span>{t.submitAdButton}</span>
            </button>
          </div>

        </form>
      )}

      {/* ACTIVE SPONSORED ADVERTISEMENTS DIRECTORY */}
      <div className="space-y-4">
        <h3 className="text-lg font-black tracking-tight font-mono flex items-center space-x-2">
          <Megaphone className="w-5 h-5 text-emerald-400" />
          <span>Anúncios Ativos na Comunidade Geneconsert</span>
        </h3>

        {loading ? (
          <div className="py-8 text-center text-xs opacity-75">A carregar anúncios...</div>
        ) : ads.length === 0 ? (
          <div className="py-8 text-center text-xs opacity-75">Nenhum anúncio publicado ainda. Seja o primeiro!</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {ads.map((ad) => (
              <div
                key={ad.id}
                className="p-6 rounded-3xl bg-gray-500/5 border border-gray-500/20 hover:border-emerald-500/40 transition-all flex flex-col justify-between space-y-4 shadow-sm relative overflow-hidden group"
              >
                <div className="space-y-3">
                  
                  {/* Category & Badge */}
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase">
                      {ad.category === 'pecas' ? 'Peças & Componentes' : ad.category === 'assistencia' ? 'Assistência Técnica' : 'Equipamentos'}
                    </span>
                    <span className="text-[10px] font-mono opacity-60">
                      Anúncio Verificado
                    </span>
                  </div>

                  <h4 className="text-lg font-black tracking-tight group-hover:text-emerald-400 transition-colors">
                    {ad.title}
                  </h4>

                  <p className="text-xs opacity-80 leading-relaxed font-medium">
                    {ad.description}
                  </p>

                  <div className="text-xs font-bold text-gray-400">
                    Empresa: <span className="text-gray-200">{ad.advertiserName}</span>
                  </div>

                </div>

                {/* Contact Action Bar */}
                <div className="pt-3 border-t border-gray-500/15 flex items-center justify-between">
                  
                  <a
                    href={`https://wa.me/${ad.contact.replace(/\D/g, '')}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs shadow flex items-center space-x-1.5"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Contactar por WhatsApp</span>
                  </a>

                  {ad.websiteUrl && (
                    <a
                      href={ad.websiteUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-xl bg-gray-500/10 hover:bg-gray-500/20 text-xs font-bold transition-colors"
                      title="Visitar Website"
                    >
                      <ExternalLink className="w-4 h-4 text-gray-300" />
                    </a>
                  )}

                </div>

              </div>
            ))}
          </div>
        )}

      </div>

    </div>
  );
};
