import React, { useState, useEffect, useRef } from 'react';
import { Camera, Upload, Play, Sparkles, AlertTriangle, CheckCircle2, Cpu, Wrench, RefreshCw, Volume2, ShieldAlert, RotateCw, ZoomIn, ZoomOut, Sliders, Maximize2, Minimize2, Image as ImageIcon, Sun, Contrast } from 'lucide-react';
import { Language, RepairDiagnosis } from '../types';
import { translations } from '../i18n';

interface ScannerViewProps {
  language: Language;
  onDiagnoseComplete: (diagnosis: RepairDiagnosis) => void;
  isAnalyzing: boolean;
  setIsAnalyzing: (loading: boolean) => void;
}

export const ScannerView: React.FC<ScannerViewProps> = ({
  language,
  onDiagnoseComplete,
  isAnalyzing,
  setIsAnalyzing,
}) => {
  const t = translations[language];
  
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [userNotes, setUserNotes] = useState<string>('');
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [detectedBrandHint, setDetectedBrandHint] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Image Adjustment state variables
  const [rotation, setRotation] = useState<number>(0);
  const [zoom, setZoom] = useState<number>(1);
  const [filterMode, setFilterMode] = useState<'normal' | 'contrast' | 'brightness' | 'circuits' | 'grayscale'>('normal');
  const [objectFit, setObjectFit] = useState<'contain' | 'cover'>('contain');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Sample test photos for instant adjustment & diagnosis
  const sampleImages = [
    {
      id: 'iphone_cracked',
      title: 'iPhone Ecrã Partido',
      category: 'Telemóvel',
      hint: 'Apple iPhone - Vidro Trincado',
      notes: 'O ecrã do iPhone partiu após queda e o touch deixa de responder na parte inferior.',
      url: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=800&auto=format&fit=crop&q=80',
    },
    {
      id: 'laptop_motherboard',
      title: 'Placa-Mãe Laptop',
      category: 'Computador',
      hint: 'Laptop Dell / HP - Sobreaquecimento',
      notes: 'O portátil desliga-se por aquecimento na ventoinha e o cooler faz barulho forte.',
      url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&auto=format&fit=crop&q=80',
    },
    {
      id: 'canon_camera',
      title: 'Câmera Canon / Nikon',
      category: 'Câmera',
      hint: 'Canon DSLR - Lente / Sensor',
      notes: 'A lente fotográfica travou no mecanismo de focagem automática.',
      url: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=800&auto=format&fit=crop&q=80',
    },
    {
      id: 'tablet_battery',
      title: 'Tablet / iPad',
      category: 'Tablet',
      hint: 'iPad / Samsung Tab - Bateria Viciada',
      notes: 'O tablet descarrega a bateria em 20 minutos e a porta USB abana.',
      url: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=800&auto=format&fit=crop&q=80',
    },
  ];

  const getFilterStyle = () => {
    switch (filterMode) {
      case 'contrast': return 'contrast(140%) brightness(110%)';
      case 'brightness': return 'brightness(135%) contrast(110%)';
      case 'circuits': return 'contrast(160%) saturate(150%) hue-rotate(10deg)';
      case 'grayscale': return 'grayscale(100%) contrast(140%)';
      default: return 'none';
    }
  };

  const handleSelectSample = (sample: typeof sampleImages[0]) => {
    setSelectedImage(sample.url);
    setDetectedBrandHint(sample.hint);
    setUserNotes(sample.notes);
    setRotation(0);
    setZoom(1);
    setFilterMode('normal');
    setObjectFit('contain');
  };

  // Quick preset issue chips
  const commonIssueChips = [
    t.screenCracked,
    t.batteryNotCharging,
    t.cameraBlurry,
    t.noPower,
    t.overheating,
    t.waterDamage,
  ];

  // Keyboard shortcut listener for ENTER key to start analysis & audio
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter' && !isAnalyzing && (selectedImage || userNotes.trim())) {
        e.preventDefault();
        handleAnalyzeAndPlay();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedImage, userNotes, isAnalyzing]);

  // Handle file upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setSelectedImage(base64);
        setCameraActive(false);
        detectBrandHint(file.name);
      };
      reader.readAsDataURL(file);
    }
  };

  // Quick detection hint based on common device names
  const detectBrandHint = (filename: string) => {
    const lower = filename.toLowerCase();
    if (lower.includes('iphone') || lower.includes('apple')) setDetectedBrandHint('Apple iPhone / iPad');
    else if (lower.includes('samsung') || lower.includes('galaxy')) setDetectedBrandHint('Samsung Galaxy');
    else if (lower.includes('canon') || lower.includes('camera')) setDetectedBrandHint('Canon / Nikon Camera');
    else if (lower.includes('dell') || lower.includes('hp') || lower.includes('laptop')) setDetectedBrandHint('Laptop / Computador');
    else setDetectedBrandHint('Marca & Modelo em Identificação Automática...');
  };

  // Camera stream handler
  const startCamera = async () => {
    try {
      setCameraActive(true);
      setErrorMsg(null);
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error('Camera access error:', err);
      setErrorMsg('Não foi possível aceder à câmera. Carregue uma imagem do seu dispositivo.');
      setCameraActive(false);
    }
  };

  const capturePhoto = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth || 640;
      canvas.height = videoRef.current.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
        const image = canvas.toDataURL('image/jpeg');
        setSelectedImage(image);
        stopCamera();
        setDetectedBrandHint('Aparelho Capturado pela Câmera');
      }
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  // Trigger analysis and audio playback on ENTER
  const handleAnalyzeAndPlay = async () => {
    if (!selectedImage && !userNotes.trim()) {
      setErrorMsg('Por favor, carregue uma foto do seu aparelho ou escreva o problema.');
      return;
    }

    setErrorMsg(null);
    setIsAnalyzing(true);

    try {
      const res = await fetch('/api/diagnose', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: selectedImage,
          userNotes: userNotes,
          language: language,
        }),
      });

      if (!res.ok) {
        throw new Error('Erro na resposta do servidor');
      }

      const diagnosis: RepairDiagnosis = await res.json();
      onDiagnoseComplete(diagnosis);
    } catch (err: any) {
      console.error('Diagnosis error:', err);
      setErrorMsg('Ocorreu um erro ao analisar o aparelho. Tente novamente.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Top Banner Notice */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-600/10 via-emerald-600/10 to-indigo-600/10 border border-blue-500/20 backdrop-blur-sm">
        <div className="flex items-start space-x-3">
          <div className="p-2 bg-blue-500/20 rounded-xl text-blue-400 font-bold shrink-0 mt-0.5">
            <Sparkles className="w-5 h-5 animate-spin-slow" />
          </div>
          <div>
            <h2 className="text-base font-bold tracking-tight">
              {t.autoDetectingBrand}
            </h2>
            <p className="text-xs opacity-85 mt-0.5">
              Tire uma foto do seu telemóvel, computador, tablet ou câmera. A IA identifica a marca, o modelo e o defeito e cria as instruções em áudio e imagens.
            </p>
          </div>
        </div>
      </div>

      {/* Main Upload / Camera Box */}
      <div className="p-6 sm:p-8 rounded-3xl border-2 border-dashed border-gray-400/30 bg-gray-500/5 hover:bg-gray-500/10 transition-all text-center relative overflow-hidden">
        
        {/* Camera Feed Mode */}
        {cameraActive ? (
          <div className="space-y-4">
            <div className="relative max-w-md mx-auto aspect-video rounded-2xl overflow-hidden border-2 border-emerald-500 shadow-xl bg-black">
              <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
              <div className="absolute inset-0 border-2 border-dashed border-emerald-400/50 rounded-2xl pointer-events-none flex items-center justify-center">
                <span className="text-xs bg-black/60 text-emerald-300 px-3 py-1 rounded-full font-mono">
                  Enquadre o aparelho aqui
                </span>
              </div>
            </div>

            <div className="flex justify-center space-x-3">
              <button
                onClick={capturePhoto}
                className="px-6 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-lg flex items-center space-x-2"
              >
                <Camera className="w-5 h-5" />
                <span>Capturar Fotografia</span>
              </button>
              <button
                onClick={stopCamera}
                className="px-4 py-3 rounded-2xl bg-gray-600 hover:bg-gray-500 text-white font-medium text-sm"
              >
                Cancelar
              </button>
            </div>
          </div>
        ) : selectedImage ? (
          /* Preview of Uploaded Photo with Image Adjustments */
          <div className="space-y-4">
            
            {/* Top Toolbar for Adjustments */}
            <div className="flex flex-wrap items-center justify-between gap-2 p-3 rounded-2xl bg-black/40 border border-gray-500/20 text-xs font-semibold">
              <div className="flex items-center space-x-2 text-blue-400 font-bold">
                <Sliders className="w-4 h-4" />
                <span>Ajustar Imagem</span>
              </div>

              {/* Adjustment Action Buttons */}
              <div className="flex flex-wrap items-center gap-1.5">
                
                {/* Rotate Button */}
                <button
                  type="button"
                  onClick={() => setRotation((prev) => (prev + 90) % 360)}
                  className="px-2.5 py-1.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-200 flex items-center space-x-1 text-[11px] font-bold transition-all"
                  title="Rodar Imagem 90°"
                >
                  <RotateCw className="w-3.5 h-3.5 text-blue-400" />
                  <span>{rotation}°</span>
                </button>

                {/* Zoom Out Button */}
                <button
                  type="button"
                  onClick={() => setZoom((prev) => Math.max(prev - 0.25, 1))}
                  className="p-1.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-200 transition-all disabled:opacity-40"
                  disabled={zoom <= 1}
                  title="Reduzir Zoom"
                >
                  <ZoomOut className="w-3.5 h-3.5" />
                </button>

                {/* Zoom Level Indicator */}
                <span className="px-2 text-[11px] font-mono font-bold text-emerald-400">
                  {Math.round(zoom * 100)}%
                </span>

                {/* Zoom In Button */}
                <button
                  type="button"
                  onClick={() => setZoom((prev) => Math.min(prev + 0.25, 2.5))}
                  className="p-1.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-200 transition-all disabled:opacity-40"
                  disabled={zoom >= 2.5}
                  title="Aumentar Zoom"
                >
                  <ZoomIn className="w-3.5 h-3.5" />
                </button>

                {/* Object Fit Toggle */}
                <button
                  type="button"
                  onClick={() => setObjectFit((prev) => (prev === 'contain' ? 'cover' : 'contain'))}
                  className="px-2.5 py-1.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-200 text-[11px] font-bold flex items-center space-x-1"
                  title="Alternar Enquadramento"
                >
                  {objectFit === 'contain' ? <Maximize2 className="w-3.5 h-3.5 text-purple-400" /> : <Minimize2 className="w-3.5 h-3.5 text-purple-400" />}
                  <span>{objectFit === 'contain' ? 'Ajustar' : 'Preencher'}</span>
                </button>

                {/* Filter Selector */}
                <select
                  value={filterMode}
                  onChange={(e) => setFilterMode(e.target.value as any)}
                  className="px-2 py-1 rounded-xl bg-gray-800 border border-gray-700 text-[11px] font-bold text-gray-200 focus:outline-none"
                >
                  <option value="normal">Filtro: Normal</option>
                  <option value="circuits">Realçar Circuitos</option>
                  <option value="contrast">Alto Contraste</option>
                  <option value="brightness">Mais Brilho</option>
                  <option value="grayscale">Preto e Branco</option>
                </select>

                {/* Reset Adjustments */}
                <button
                  type="button"
                  onClick={() => { setRotation(0); setZoom(1); setFilterMode('normal'); setObjectFit('contain'); }}
                  className="px-2 py-1.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-400 text-[11px] font-semibold"
                  title="Repor Ajustes"
                >
                  Reset
                </button>

              </div>
            </div>

            {/* Image Viewport Container */}
            <div className="relative max-w-md mx-auto aspect-video rounded-2xl overflow-hidden border-2 border-blue-500 shadow-2xl bg-black group flex items-center justify-center">
              
              <div className="w-full h-full flex items-center justify-center overflow-hidden">
                <img
                  src={selectedImage}
                  alt="Device preview"
                  style={{
                    transform: `rotate(${rotation}deg) scale(${zoom})`,
                    filter: getFilterStyle(),
                    objectFit: objectFit,
                  }}
                  className="w-full h-full transition-all duration-300"
                />
              </div>
              
              {detectedBrandHint && (
                <div className="absolute top-3 left-3 bg-black/80 backdrop-blur-md text-emerald-400 px-3 py-1 rounded-xl text-xs font-mono border border-emerald-500/40 flex items-center space-x-1.5 shadow-md">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{detectedBrandHint}</span>
                </div>
              )}

              <button
                onClick={() => { setSelectedImage(null); setDetectedBrandHint(null); setRotation(0); setZoom(1); }}
                className="absolute top-3 right-3 bg-red-600/90 hover:bg-red-600 text-white p-2 rounded-xl text-xs font-bold transition-transform group-hover:scale-105 shadow-md"
                title="Trocar Foto"
              >
                Trocar Foto
              </button>
            </div>

            <p className="text-xs opacity-75 font-medium">
              Imagem ajustada com sucesso! Rotação: {rotation}°, Zoom: {Math.round(zoom * 100)}%. Prima <kbd className="px-1.5 py-0.5 bg-gray-500/20 rounded font-mono font-bold text-[10px]">ENTER</kbd> para diagnosticar.
            </p>

          </div>
        ) : (
          /* Default Upload Options + Sample Image Shortcuts */
          <div className="space-y-6">
            <div className="w-20 h-20 mx-auto rounded-3xl bg-blue-500/10 text-blue-500 flex items-center justify-center border border-blue-500/20 shadow-inner">
              <Camera className="w-10 h-10 animate-bounce-slow" />
            </div>

            <div>
              <h3 className="text-lg font-extrabold tracking-tight">
                {t.dragDropImage}
              </h3>
              <p className="text-xs opacity-75 max-w-md mx-auto mt-1">
                Suporta fotos de Celulares, Computadores, Tablets, Câmeras fotográficas Canon/Nikon/Sony e Consolas de Jogos.
              </p>
            </div>

            <div className="flex flex-wrap justify-center gap-3">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-6 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center space-x-2"
              >
                <Upload className="w-4 h-4" />
                <span>{t.uploadPhoto}</span>
              </button>

              <button
                onClick={startCamera}
                className="px-6 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center space-x-2"
              >
                <Camera className="w-4 h-4" />
                <span>{t.takePhoto}</span>
              </button>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />
            </div>

            {/* Quick Sample Presets for Testing Image Adjustment */}
            <div className="pt-4 border-t border-gray-500/15">
              <span className="text-xs font-bold opacity-80 block mb-3">
                📸 Ou escolha uma imagem de teste para experimentar os ajustes:
              </span>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {sampleImages.map((sample) => (
                  <button
                    key={sample.id}
                    type="button"
                    onClick={() => handleSelectSample(sample)}
                    className="group p-2 rounded-2xl bg-black/30 border border-gray-500/20 hover:border-blue-500/50 transition-all text-left flex flex-col items-center space-y-1.5"
                  >
                    <div className="w-full aspect-video rounded-xl overflow-hidden bg-gray-900 border border-white/10 relative">
                      <img src={sample.url} alt={sample.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300" />
                      <span className="absolute bottom-1 right-1 bg-black/70 text-[9px] font-mono text-emerald-400 px-1.5 py-0.5 rounded">
                        {sample.category}
                      </span>
                    </div>
                    <span className="text-[11px] font-bold line-clamp-1 group-hover:text-blue-400 transition-colors">
                      {sample.title}
                    </span>
                  </button>
                ))}
              </div>
            </div>

          </div>
        )}

      </div>

      {/* Description input & Common Issues selection */}
      <div className="p-6 rounded-3xl bg-gray-500/5 border border-gray-500/20 space-y-4">
        
        <label className="block text-sm font-bold tracking-tight">
          Descrição opcional do problema (ou selecione uma opção):
        </label>

        <textarea
          value={userNotes}
          onChange={(e) => setUserNotes(e.target.value)}
          placeholder="Ex: O ecrã do meu iPhone 13 partiu e não dá imagem, ou a câmera Canon Rebel T7 ficou com manchas na lente..."
          rows={3}
          className="w-full px-4 py-3 rounded-2xl bg-gray-500/10 border border-gray-500/30 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none font-sans"
        />

        {/* Quick Issue Chips */}
        <div>
          <span className="text-xs opacity-75 font-semibold block mb-2">
            {t.commonIssuesTitle}
          </span>
          <div className="flex flex-wrap gap-2">
            {commonIssueChips.map((chip, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setUserNotes((prev) => (prev ? `${prev}, ${chip}` : chip))}
                className="px-3 py-1.5 rounded-xl bg-gray-500/10 hover:bg-blue-500/20 border border-gray-500/20 text-xs font-medium transition-all hover:scale-105"
              >
                + {chip}
              </button>
            ))}
          </div>
        </div>

      </div>

      {errorMsg && (
        <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-500 text-xs font-semibold flex items-center space-x-2">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* BIG PROMINENT ENTER BUTTON REQUIRED BY USER SPEC */}
      <div className="pt-2 text-center space-y-3">
        
        <p className="text-xs font-bold text-emerald-400 dark:text-emerald-300 uppercase tracking-widest flex items-center justify-center space-x-1.5 animate-pulse">
          <Volume2 className="w-4 h-4" />
          <span>{t.pressEnterToStart}</span>
        </p>

        <button
          onClick={handleAnalyzeAndPlay}
          disabled={isAnalyzing}
          className={`w-full py-5 rounded-3xl text-white font-black text-lg sm:text-xl tracking-wider shadow-2xl transition-all duration-300 flex items-center justify-center space-x-3 border-2 border-emerald-400/30 ${
            isAnalyzing
              ? 'bg-gray-600 cursor-not-allowed opacity-80'
              : 'bg-gradient-to-r from-emerald-600 via-teal-600 to-blue-600 hover:from-emerald-500 hover:to-blue-500 hover:scale-[1.02] active:scale-[0.98]'
          }`}
        >
          {isAnalyzing ? (
            <>
              <RefreshCw className="w-7 h-7 animate-spin" />
              <span>{t.analyzingDevice}</span>
            </>
          ) : (
            <>
              <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center">
                <Play className="w-6 h-6 text-white fill-current ml-0.5" />
              </div>
              <div className="text-left">
                <div className="leading-tight">{t.enterButtonText}</div>
                <div className="text-xs font-normal opacity-90">{t.enterSubtitle}</div>
              </div>
            </>
          )}
        </button>

        <div className="flex items-center justify-center space-x-2 text-xs opacity-60">
          <kbd className="px-2 py-1 bg-gray-500/20 rounded-md border border-gray-500/30 font-mono text-[11px] font-bold">
            ENTER
          </kbd>
          <span>Pressione a tecla Enter no seu teclado para iniciar a qualquer momento</span>
        </div>

      </div>

    </div>
  );
};
